#!/bin/bash
# eBay Titan AI — Build Script
# Works on Vercel, Netlify, Railway.
# Node.js injection is cross-platform (no perl/sed edge cases).
set -e
echo "=== eBay Titan AI Build === Node: $(node --version)"
MISS=""
for V in VITE_FIREBASE_API_KEY VITE_FIREBASE_AUTH_DOMAIN VITE_FIREBASE_PROJECT_ID \
         VITE_FIREBASE_STORAGE_BUCKET VITE_FIREBASE_MESSAGING_SENDER_ID VITE_FIREBASE_APP_ID; do
  [ -z "${!V}" ] && { echo "  MISSING: $V"; MISS="$MISS $V"; } || echo "  OK: $V"
done
[ -n "$MISS" ] && { echo "ERROR: Set missing vars in dashboard then redeploy"; exit 1; }

rm -rf dist && mkdir -p dist/emails
cp *.html dist/
cp *.js   dist/
cp *.css  dist/
[ -f _redirects ] && cp _redirects dist/
[ -f robots.txt ] && cp robots.txt dist/
[ -f sitemap.xml ] && cp sitemap.xml dist/
cp emails/*.html dist/emails/ 2>/dev/null || true
echo "Copied $(ls dist/*.html|wc -l) HTML, $(ls dist/*.js|wc -l) JS, $(ls dist/*.css|wc -l) CSS"

node << 'INJECT'
const fs  = require("fs");
const src = "dist/firebase-config.js";
let c = fs.readFileSync(src, "utf8");
const subs = [
  ["REPLACE_WITH_YOUR_API_KEY",                    process.env.VITE_FIREBASE_API_KEY],
  ["REPLACE_WITH_YOUR_PROJECT_ID.firebaseapp.com", process.env.VITE_FIREBASE_AUTH_DOMAIN],
  ["REPLACE_WITH_YOUR_PROJECT_ID.appspot.com",     process.env.VITE_FIREBASE_STORAGE_BUCKET],
  ["REPLACE_WITH_YOUR_PROJECT_ID",                 process.env.VITE_FIREBASE_PROJECT_ID],
  ["REPLACE_WITH_YOUR_SENDER_ID",                  process.env.VITE_FIREBASE_MESSAGING_SENDER_ID],
  ["REPLACE_WITH_YOUR_APP_ID",                     process.env.VITE_FIREBASE_APP_ID],
];
for (const [k, v] of subs) { if (c.includes(k)) c = c.split(k).join(v); }
fs.writeFileSync(src, c, "utf8");
const m = c.match(/apiKey:\s*"([^"]+)"/);
if (!m || !m[1] || m[1].includes("REPLACE")) {
  console.error("ERROR: Firebase apiKey not injected. Check env vars.");
  process.exit(1);
}
console.log("Firebase injected. apiKey: " + m[1].slice(0, 9) + "...");
INJECT

[ -f dist/index.html ] && [ -f dist/firebase-config.js ] && [ -f dist/_redirects ] \
  || { echo "ERROR: critical files missing from dist/"; exit 1; }
echo "=== Build OK — dist/ ($(ls dist/|wc -l) files) ==="
