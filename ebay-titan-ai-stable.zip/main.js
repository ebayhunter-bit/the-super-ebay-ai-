/* ═══════════════════════════════════════════════════════════
   eBay TITAN AI — main.js
   Real Firebase Authentication + All UI Interactions
   ═══════════════════════════════════════════════════════════ */

"use strict";

/* ── DOMContentLoaded wrapper ── */
document.addEventListener("DOMContentLoaded", function () {

  /* ══════════════════════════════════════════
     0. PRODUCTION CONSOLE CLEANUP
     Remove verbose warnings in production
  ══════════════════════════════════════════ */
  if (window.location.hostname !== "localhost" && !window.location.hostname.includes("127.")) {
    // Suppress non-critical warnings in production but keep errors
    const origWarn = console.warn;
    console.warn = function(...args) {
      // Allow Firebase internal warnings (useful for debugging) but filter noise
      const msg = args.join(" ");
      if (msg.includes("Firestore") || msg.includes("Firebase") || msg.includes("[Titan]")) {
        origWarn.apply(console, args);
      }
    };
  }

  /* ══════════════════════════════════════════
     0b. TOUCH RIPPLE EFFECT on .btn-glow
  ══════════════════════════════════════════ */
  document.addEventListener("click", e => {
    const btn = e.target.closest(".btn-glow");
    if (!btn) return;
    const ripple = document.createElement("span");
    ripple.className = "ripple";
    const rect = btn.getBoundingClientRect();
    ripple.style.cssText = `
      left:${e.clientX - rect.left - 10}px;
      top:${e.clientY - rect.top - 10}px;
    `;
    btn.style.position = "relative";
    btn.style.overflow = "hidden";
    btn.appendChild(ripple);
    ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
  }, { passive: true });

  /* ══════════════════════════════════════════
     1. NAVBAR — scroll shadow + hamburger
  ══════════════════════════════════════════ */
  const navbar    = document.getElementById("navbar");
  const hamburger = document.getElementById("hamburger");
  let mobileMenu  = document.getElementById("mobileMenu");

  if (!mobileMenu && navbar) {
    mobileMenu = document.createElement("div");
    mobileMenu.id = "mobileMenu";
    mobileMenu.className = "nav-mobile";
    mobileMenu.innerHTML = `
      <a href="index.html#features"  data-i18n="nav_features">Features</a>
      <a href="index.html#how"       data-i18n="nav_how">How It Works</a>
      <a href="index.html#tutorials" data-i18n="nav_tutorials">Tutorials</a>
      <a href="index.html#pricing"   data-i18n="nav_pricing">Pricing</a>
      <a href="index.html#faq"       data-i18n="nav_faq">FAQ</a>
      <a href="login.html"           data-i18n="nav_login">Login</a>
    `;
    navbar.after(mobileMenu);
  }

  window.addEventListener("scroll", () => {
    if (navbar) navbar.classList.toggle("scrolled", window.scrollY > 30);
  }, { passive: true });

  if (hamburger) {
    hamburger.addEventListener("click", () => {
      const isOpen = mobileMenu && mobileMenu.classList.toggle("open");
      hamburger.classList.toggle("open", !!isOpen);
      hamburger.setAttribute("aria-expanded", String(!!isOpen));
    });
    document.addEventListener("click", e => {
      if (mobileMenu?.classList.contains("open") &&
          !mobileMenu.contains(e.target) && !hamburger.contains(e.target)) {
        mobileMenu.classList.remove("open");
        hamburger.classList.remove("open");
      }
    });
  }

  /* ══════════════════════════════════════════
     2. LANGUAGE SWITCHER
  ══════════════════════════════════════════ */
  const langBtn      = document.getElementById("langBtn");
  const langDropdown = document.getElementById("langDropdown");

  if (langBtn && langDropdown) {
    langBtn.addEventListener("click", e => {
      e.stopPropagation();
      const open = langDropdown.classList.toggle("open");
      langBtn.setAttribute("aria-expanded", String(open));
    });
    document.querySelectorAll(".lang-option").forEach(btn => {
      btn.addEventListener("click", () => {
        if (window.applyLang) window.applyLang(btn.dataset.lang);
        langDropdown.classList.remove("open");
        langBtn.setAttribute("aria-expanded", "false");
      });
    });
    document.addEventListener("click", e => {
      if (!langBtn.contains(e.target) && !langDropdown.contains(e.target)) {
        langDropdown.classList.remove("open");
        langBtn.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ══════════════════════════════════════════
     3. LIVE COUNTER — hero badge
  ══════════════════════════════════════════ */
  const liveCount = document.getElementById("liveCount");
  if (liveCount) {
    let count = 0;
    const target = 2847 + Math.floor(Math.random() * 200);
    const step   = Math.ceil(target / 60);
    const timer  = setInterval(() => {
      count = Math.min(count + step + Math.floor(Math.random() * 8), target);
      liveCount.textContent = count.toLocaleString();
      if (count >= target) clearInterval(timer);
    }, 40);
  }

  /* ══════════════════════════════════════════
     4. TUTORIAL PANEL SWITCHER
  ══════════════════════════════════════════ */
  const tutNavBtns = document.querySelectorAll(".tut-nav-btn");
  const tutPanels  = document.querySelectorAll(".tut-panel");
  const tutCurrent = document.getElementById("tutCurrent");
  const tutPrev    = document.getElementById("tutPrev");
  const tutNext    = document.getElementById("tutNext");
  let currentTut   = 0;

  function setTut(idx) {
    if (idx < 0 || idx >= tutPanels.length) return;
    currentTut = idx;
    tutNavBtns.forEach((b, i) => b.classList.toggle("active", i === idx));
    tutPanels.forEach((p, i) => p.classList.toggle("active", i === idx));
    if (tutCurrent) tutCurrent.textContent = idx + 1;
    if (tutPrev) tutPrev.disabled = (idx === 0);
    if (tutNext) tutNext.disabled = (idx === tutPanels.length - 1);
    const sec = document.getElementById("tutorials");
    if (sec) window.scrollTo({ top: sec.getBoundingClientRect().top + window.scrollY - 100, behavior: "smooth" });
  }

  tutNavBtns.forEach((btn, i) => btn.addEventListener("click", () => setTut(i)));
  if (tutPrev) tutPrev.addEventListener("click", () => setTut(currentTut - 1));
  if (tutNext) tutNext.addEventListener("click", () => setTut(currentTut + 1));
  if (tutPanels.length) setTut(0);

  /* ══════════════════════════════════════════
     5. COPY BUTTONS
  ══════════════════════════════════════════ */
  document.querySelectorAll(".copy-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const code = btn.dataset.code || btn.closest(".tut-step")?.querySelector("pre")?.textContent || "";
      if (navigator.clipboard) {
        navigator.clipboard.writeText(code).then(() => {
          btn.textContent = "✓ Copied"; btn.classList.add("copied");
          setTimeout(() => { btn.textContent = "Copy"; btn.classList.remove("copied"); }, 2200);
        }).catch(() => fallbackCopy(btn, code));
      } else { fallbackCopy(btn, code); }
    });
  });

  function fallbackCopy(btn, text) {
    const ta = document.createElement("textarea");
    ta.value = text; ta.style.cssText = "position:fixed;top:-9999px;left:-9999px;";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); btn.textContent = "✓ Copied"; btn.classList.add("copied"); }
    catch(e) { btn.textContent = "Error"; }
    document.body.removeChild(ta);
    setTimeout(() => { btn.textContent = "Copy"; btn.classList.remove("copied"); }, 2200);
  }

  /* ══════════════════════════════════════════
     6. FAQ ACCORDION
  ══════════════════════════════════════════ */
  document.querySelectorAll(".faq-item").forEach(item => {
    const btn = item.querySelector(".faq-q");
    if (!btn) return;
    btn.addEventListener("click", () => {
      const isOpen = item.classList.toggle("open");
      btn.setAttribute("aria-expanded", String(isOpen));
      document.querySelectorAll(".faq-item.open").forEach(other => {
        if (other !== item) {
          other.classList.remove("open");
          other.querySelector(".faq-q")?.setAttribute("aria-expanded", "false");
        }
      });
    });
  });

  /* ══════════════════════════════════════════
     7. CONTACT FORM
  ══════════════════════════════════════════ */
  const contactSend    = document.getElementById("contactSend");
  const contactSuccess = document.getElementById("contactSuccess");

  if (contactSend) {
    contactSend.addEventListener("click", () => {
      const name    = document.getElementById("cName")?.value.trim();
      const email   = document.getElementById("cEmail")?.value.trim();
      const subject = document.getElementById("cSubject")?.value.trim();
      const msg     = document.getElementById("cMsg")?.value.trim();
      if (!name || !email || !subject || !msg || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        contactSend.style.animation = "none";
        contactSend.offsetHeight;
        contactSend.style.animation = "shake 0.4s ease";
        return;
      }
      contactSend.disabled = true;
      contactSend.textContent = "⟳ Sending...";
      setTimeout(() => {
        contactSend.style.display = "none";
        if (contactSuccess) contactSuccess.classList.remove("hidden");
        ["cName","cEmail","cSubject","cMsg"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; });
      }, 1200);
    });
  }

  /* ══════════════════════════════════════════
     8. SCROLL-REVEAL
  ══════════════════════════════════════════ */
  if ("IntersectionObserver" in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.style.animation = "fadeUp 0.6s cubic-bezier(.22,1,.36,1) both";
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll(".feat-card,.step-card,.tg-card,.test-card,.faq-item,.dl-item,.dash-tut-card").forEach(el => obs.observe(el));
  }

  /* ══════════════════════════════════════════
     9. BACK TO TOP
  ══════════════════════════════════════════ */
  const btt = document.getElementById("backToTop");
  if (btt) {
    window.addEventListener("scroll", () => btt.classList.toggle("visible", window.scrollY > 500), { passive: true });
    btt.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  }

  /* ══════════════════════════════════════════
     10. SMOOTH SCROLL
  ══════════════════════════════════════════ */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", e => {
      const id = link.getAttribute("href").slice(1);
      const target = document.getElementById(id);
      if (target) {
        e.preventDefault();
        window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - 80, behavior: "smooth" });
        if (mobileMenu) mobileMenu.classList.remove("open");
      }
    });
  });

  /* ══════════════════════════════════════════
     11. FIREBASE ROUTE GUARD — Dashboard pages
     Real Firebase Auth — no fake session bypass
  ══════════════════════════════════════════ */
  const isDashboard = document.body.classList.contains("dashboard-page");
  const isAdminPage = document.body.classList.contains("admin-page");

  if (isDashboard) {
    initDashboardWithFirebase();
  }

  if (isAdminPage) {
    initAdminWithFirebase();
  }

  /* ══════════════════════════════════════════
     12. FLOATING AI MENTOR WIDGET
  ══════════════════════════════════════════ */
  if (!document.querySelector(".ai-float-widget")) {
    injectFloatingAI();
  }

}); /* end DOMContentLoaded */

/* ════════════════════════════════════════════════
   INPUT SECURITY HELPERS
════════════════════════════════════════════════ */
function sanitizeInput(str) {
  if (typeof str !== "string") return "";
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
            .replace(/"/g,"&quot;").replace(/'/g,"&#x27;").trim().slice(0, 500);
}

function logSecurityEvent(type, data = {}) {
  try {
    if (window.titanAuth && window.getFirebase) {
      const { db } = getFirebase();
      db.collection("security_logs").add({
        type, data,
        url:       window.location.href,
        userAgent: navigator.userAgent.slice(0, 200),
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      }).catch(() => {});
    }
  } catch(_) {}
}

/* ════════════════════════════════════════════════
   DASHBOARD — Firebase Auth Guard + Real Session
════════════════════════════════════════════════ */

// Stores the verified user data once auth resolves
window._titanUser = null;

function initDashboardWithFirebase() {
  const loadingOverlay = document.getElementById("dashAuthLoading");
  const dashMain       = document.getElementById("dashMainContent");

  // Show loading while Firebase checks auth state
  if (loadingOverlay) loadingOverlay.style.display = "flex";
  if (dashMain)       dashMain.style.display = "none";

  // requireAuth: blocks access, redirects if not authenticated/verified/paid
  titanAuth.requireAuth().then((userData) => {
    window._titanUser = userData;

    // Hide loading, show content
    if (loadingOverlay) loadingOverlay.style.display = "none";
    if (dashMain)       dashMain.style.display = "block";

    // Populate user info in UI
    document.querySelectorAll(".dash-user-email").forEach(el => { el.textContent = userData.email; });
    document.querySelectorAll(".dash-user-name").forEach(el => {
      el.textContent = userData.name || userData.firstName || userData.email.split("@")[0];
    });

    // Show admin badge if applicable
    if (userData.role === "admin") {
      document.querySelectorAll(".admin-only-badge").forEach(el => el.style.display = "");
    }

    // ── Populate welcome banner ──
    const displayName = userData.firstName || userData.name || userData.email.split("@")[0];
    const hour = new Date().getHours();
    const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
    const welcomeHeading = document.getElementById("welcomeHeading");
    const overviewAvatar = document.getElementById("overviewAvatar");
    if (welcomeHeading) welcomeHeading.textContent = `${greeting}, ${displayName}! 👋`;
    if (overviewAvatar)  overviewAvatar.textContent = (displayName[0] || "U").toUpperCase();

    // ── Populate workspace, plan & scans remaining (Phase 4/9) ──
    titanAuth.getUserDoc(userData.uid).then(doc => {
      if (doc) {
        const plan = doc.plan || (doc.hasAccess ? "pro" : "free");
        const planLabel = plan === "premium" ? "Premium" : plan === "pro" ? "Pro" : "Free";
        document.querySelectorAll(".dash-plan-label").forEach(el => { el.textContent = planLabel; });
        document.querySelectorAll(".dash-workspace-name").forEach(el => {
          el.textContent = doc.workspace || (displayName + "'s Workspace");
        });
        // Scans remaining (free plan only; paid = unlimited)
        const today = new Date(); const todayStr = today.getFullYear()+"-"+(today.getMonth()+1)+"-"+today.getDate();
        const used = (doc.scanDate === todayStr) ? (doc.scansToday||0) : 0;
        const remaining = (plan === "free") ? Math.max(0, 3 - used) : "∞";
        document.querySelectorAll(".dash-scans-remaining").forEach(el => {
          el.textContent = (plan === "free") ? (remaining + " / 3") : "Unlimited";
        });
        // Avatar (use Avatar lib if a workspace avatar was chosen)
        if (doc.avatarId && window.Avatar) {
          document.querySelectorAll("#overviewAvatar, #profileAvatar").forEach(el => {
            el.innerHTML = window.Avatar.img(doc.avatarId, "", 48, "dash-av-img", 0);
          });
        }
        // Apply saved theme (Phase 12)
        if (doc.theme && doc.theme !== "titan-dark") {
          document.documentElement.setAttribute("data-theme", doc.theme);
        }
      }
    }).catch(() => {});

    // ── Load Firestore progress & sync to localStorage ──
    titanAuth.getUserDoc(userData.uid).then(doc => {
      if (doc?.progress && Array.isArray(doc.progress)) {
        try { localStorage.setItem("titan_progress", JSON.stringify(doc.progress)); } catch(_) {}
        if (typeof window.loadProgress === "function") window.loadProgress();
      }
      if (doc?.lastActivity) {
        const feedEl = document.getElementById("activityFeed");
        if (feedEl) {
          const lastDate = new Date(doc.lastActivity);
          const dayStr   = lastDate.toLocaleDateString("en-GB", { day:"numeric", month:"short" });
          const newItem  = document.createElement("div");
          newItem.className = "activity-item";
          newItem.innerHTML = `<div class="activity-icon">📖</div><div><div class="activity-text">Last session: <strong>${dayStr}</strong></div><div style="font-size:11px;color:var(--muted)">${lastDate.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</div></div>`;
          feedEl.insertBefore(newItem, feedEl.firstChild);
        }
      }
    }).catch(() => {});

    // Wire panel navigation, logout, and everything else
    initDashboardUI(userData);
    initDashAIChat();
    initIdleTimer();

  }).catch((err) => {
    // requireAuth already redirected — nothing to do here
    console.warn("Dashboard auth failed:", err.message);
  });
}

function initAdminWithFirebase() {
  const loadingOverlay = document.getElementById("adminAuthLoading");
  const adminMain      = document.getElementById("adminMainContent");

  if (loadingOverlay) loadingOverlay.style.display = "flex";
  if (adminMain)      adminMain.style.display = "none";

  titanAuth.requireAdmin().then((userData) => {
    window._titanUser = userData;

    if (loadingOverlay) loadingOverlay.style.display = "none";
    if (adminMain)      adminMain.style.display = "block";

    document.querySelectorAll(".dash-user-email").forEach(el => { el.textContent = userData.email; });
    initAdminUI(userData);

  }).catch((err) => {
    console.warn("Admin auth failed:", err.message);
  });
}

/* ── Dashboard UI wiring (called after auth confirms) ── */
function initDashboardUI(userData) {
  const navBtns  = document.querySelectorAll(".dash-nav-btn[data-panel]");
  const panels   = document.querySelectorAll(".dash-panel");
  const logoutBt = document.getElementById("dashLogout");

  const panelMeta = {
    overview:   { title: "Dashboard Overview",      sub: "Welcome back — your eBay Titan AI platform" },
    tutorials:  { title: "Tutorials",               sub: "8 step-by-step guides — English & Arabic" },
    downloads:  { title: "Downloads",               sub: "All files included with your lifetime access" },
    ai:         { title: "AI Mentor",               sub: "Ask anything — instant answers in any language" },
    ebay:       { title: "eBay API Guide",           sub: "Set up your eBay developer credentials" },
    telegram:   { title: "Telegram Setup",           sub: "Create and configure your Telegram bot" },
    botinstall: { title: "Bot Installation",         sub: "Install, configure, and deploy the bot" },
    support:    { title: "Support Center",           sub: "Get help from our team or AI mentor" },
    profile:    { title: "My Profile",               sub: "Manage your account settings" },
  };

  window.setDashPanel = function (name) {
    navBtns.forEach(b => b.classList.toggle("active", b.dataset.panel === name));
    panels.forEach(p => {
      const isTarget = p.dataset.panel === name;
      if (isTarget && !p.classList.contains("active")) {
        p.style.opacity = "0";
        p.style.transform = "translateY(8px)";
        p.classList.add("active");
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            p.style.transition = "opacity .3s ease, transform .3s ease";
            p.style.opacity = "1";
            p.style.transform = "translateY(0)";
          });
        });
      } else if (!isTarget) {
        p.classList.remove("active");
      }
    });
    const meta = panelMeta[name] || {};
    const t = document.getElementById("panelTitle");
    const s = document.getElementById("panelSubtitle");
    if (t) t.textContent = meta.title || name;
    if (s) s.textContent = meta.sub || "";
    try { sessionStorage.setItem("titan_last_panel", name); } catch(_) {}
    const sidebar = document.getElementById("dashSidebar");
    if (sidebar && window.innerWidth <= 900) sidebar.classList.remove("open");
  };

  navBtns.forEach(btn => btn.addEventListener("click", () => setDashPanel(btn.dataset.panel)));

  const lastPanel = (() => { try { return sessionStorage.getItem("titan_last_panel") || "overview"; } catch(_) { return "overview"; } })();
  setDashPanel(lastPanel);

  // Logout — real Firebase signOut
  if (logoutBt) {
    logoutBt.addEventListener("click", async () => {
      try {
        await titanAuth.logout();
      } catch(_) {}
      window.location.replace("login.html?reason=logout");
    });
  }

  // Sidebar mobile toggle
  const sideToggle = document.getElementById("sidebarToggle");
  const sidebar    = document.getElementById("dashSidebar");
  if (sideToggle && sidebar) {
    sideToggle.addEventListener("click", () => sidebar.classList.toggle("open"));
    document.addEventListener("click", e => {
      if (sidebar.classList.contains("open") && !sidebar.contains(e.target) && !sideToggle.contains(e.target))
        sidebar.classList.remove("open");
    });
  }

  // Profile panel — populate with Firebase user data
  const profileEmailInput = document.getElementById("profileEmailInput");
  const profileNameInput  = document.getElementById("profileNameInput");
  const profileAvatar     = document.getElementById("profileAvatar");
  if (profileEmailInput) profileEmailInput.value = userData.email;
  if (profileNameInput)  profileNameInput.value  = userData.name || "";
  if (profileAvatar)     profileAvatar.textContent = (userData.name || userData.email)[0].toUpperCase();

  // Save profile
  const saveProfileBtn = document.getElementById("saveProfileBtn");
  if (saveProfileBtn) {
    saveProfileBtn.addEventListener("click", async () => {
      const newName = profileNameInput?.value.trim();
      try {
        await titanAuth.updateUserDoc(userData.uid, { firstName: newName });
        const { auth } = getFirebase();
        await auth.currentUser?.updateProfile({ displayName: newName });
        const saved = document.getElementById("profileSaved");
        if (saved) { saved.style.display = "block"; setTimeout(() => saved.style.display = "none", 3000); }
      } catch(err) {
        console.error("Profile save error:", err);
      }
    });
  }

  // Copy buttons in dashboard
  document.querySelectorAll(".copy-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const code = btn.dataset.code || btn.closest(".tut-step")?.querySelector("pre")?.textContent || "";
      navigator.clipboard?.writeText(code).then(() => {
        btn.textContent = "✓ Copied";
        setTimeout(() => btn.textContent = "Copy", 2000);
      });
    });
  });
}

/* ── Admin UI wiring ── */
function initAdminUI(userData) {
  // Populate stats
  titanAuth.getStats().then(stats => {
    const els = {
      adminTotalUsers:  stats.totalUsers,
      adminWithAccess:  stats.withAccess,
      adminNewThisWeek: stats.newThisWeek,
    };
    Object.entries(els).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    });
  }).catch(() => {});

  // Load users table
  loadAdminUsers();

  // Logout
  document.getElementById("adminLogout")?.addEventListener("click", async () => {
    await titanAuth.logout();
    window.location.replace("login.html?reason=logout");
  });
}

function loadAdminUsers() {
  const tbody = document.getElementById("adminUsersBody");
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:20px">⟳ Loading users...</td></tr>`;

  titanAuth.listUsers(200).then(users => {
    if (!users.length) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:20px">No users found.</td></tr>`;
      return;
    }
    tbody.innerHTML = users.map(u => `
      <tr>
        <td style="font-family:var(--font-m);font-size:12px;color:var(--text-2)">${u.email}</td>
        <td style="font-size:12px;color:var(--muted)">${u.firstName || "—"}</td>
        <td>
          <span class="badge-${u.role === "admin" ? "amber" : "blue"}" style="font-size:10px">
            ${u.role || "user"}
          </span>
        </td>
        <td>
          <span class="badge-${u.hasAccess ? "green" : "red"}" style="font-size:10px">
            ${u.hasAccess ? "✓ Active" : "✗ No Access"}
          </span>
        </td>
        <td style="font-size:11px;color:var(--muted)">
          ${u.createdAt?.toDate ? u.createdAt.toDate().toLocaleDateString() : "—"}
        </td>
        <td>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${!u.hasAccess ? `<button class="btn-ghost" style="font-size:11px;padding:4px 10px" onclick="adminGrantAccess('${u.uid}', this)">Grant Access</button>` : `<button class="btn-ghost" style="font-size:11px;padding:4px 10px;border-color:rgba(239,68,68,.3);color:#fca5a5" onclick="adminRevokeAccess('${u.uid}', this)">Revoke</button>`}
          </div>
        </td>
      </tr>
    `).join("");
  }).catch(err => {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#fca5a5;padding:20px">Error loading users: ${err.message}</td></tr>`;
  });
}

window.adminGrantAccess = async function(uid, btn) {
  btn.disabled = true; btn.textContent = "⟳";
  try {
    await titanAuth.adminSetAccess(uid, true);
    loadAdminUsers();
  } catch(err) {
    btn.disabled = false; btn.textContent = "Grant Access";
    alert("Error: " + err.message);
  }
};

window.adminRevokeAccess = async function(uid, btn) {
  if (!confirm("Revoke this user's platform access?")) return;
  btn.disabled = true; btn.textContent = "⟳";
  try {
    await titanAuth.adminSetAccess(uid, false);
    loadAdminUsers();
  } catch(err) {
    btn.disabled = false; btn.textContent = "Revoke";
    alert("Error: " + err.message);
  }
};

/* ── Idle timer — auto logout after 30 min inactivity ── */
let _idleTimer = null;
let _idleWarned = false;

function initIdleTimer() {
  const IDLE_WARN = 25 * 60 * 1000;  // warn at 25 min
  const IDLE_OUT  = 30 * 60 * 1000;  // sign out at 30 min

  function resetIdle() {
    if (_idleWarned) {
      // User came back — hide warning
      const banner = document.getElementById("sessionBanner");
      if (banner) banner.classList.remove("show");
      _idleWarned = false;
    }
    clearTimeout(_idleTimer);
    _idleTimer = setTimeout(onIdleWarn, IDLE_WARN);
  }

  async function onIdleWarn() {
    _idleWarned = true;
    const banner = document.getElementById("sessionBanner");
    if (banner) banner.classList.add("show");

    // Auto sign out after warning
    _idleTimer = setTimeout(async () => {
      try { await titanAuth.logout(); } catch(_) {}
      window.location.replace("login.html?reason=timeout");
    }, IDLE_OUT - IDLE_WARN);
  }

  // Extend session from banner button
  document.getElementById("extendSession")?.addEventListener("click", resetIdle);

  // Reset on any user interaction
  ["mousemove","keydown","scroll","click","touchstart"].forEach(ev =>
    document.addEventListener(ev, resetIdle, { passive: true })
  );

  resetIdle();
}

/* ════════════════════════════════════════════════
   AI CHAT — Dashboard panel
════════════════════════════════════════════════ */
const AI_SYSTEM_PROMPT = `You are the eBay Titan AI Mentor — an expert assistant embedded inside a premium SaaS educational platform that teaches users to build an AI-powered eBay dropshipping research bot that sends product alerts to Telegram.

You are friendly, professional, and concise. You speak like a senior developer helping a beginner.

Your expertise covers:
- eBay Browse API (OAuth, APP_ID, CLIENT_SECRET, unitSoldCount, watchCount, fieldgroups=EXTENDED)
- Telegram Bot API (BotFather, tokens, Chat IDs, formatted Markdown messages)
- Python setup (3.10+, pip, venv, package installation)
- VSCode configuration and extensions
- python-dotenv, requests, python-telegram-bot, schedule packages
- .env file security and best practices
- Railway.app cloud deployment
- JSON-based seen-items database (auto-clean at 3000 entries)
- 27-keyword scanning across 6 niches: health/posture, pet accessories, kitchen tools, car accessories, home office, fitness
- VERO brand filtering and blocked-term lists
- Common errors: SyntaxError from curly quotes, ModuleNotFoundError, 401 Unauthorized, SSL errors, Telegram auth errors
- Scoring system (unitSoldCount × weight + watchCount × weight + seller feedback)
- Tiered labels: WINNER (60+), HOT (70+), FIRE (80+), ULTRA WINNER (90+)
- Railway environment variables, Procfile, requirements.txt
- eBay free developer tier limits (~5000 calls/day)
- Firebase Authentication, Firestore security rules, platform setup

Language rules:
- If the user writes in Arabic, respond fully in Arabic.
- If the user writes in Hebrew, respond in Hebrew.
- Otherwise respond in English.
- Never switch language mid-response.

Format rules:
- Use backticks for code/commands inline
- Use short code blocks for multi-line code
- Be direct. Beginners appreciate clarity over verbosity.
- Maximum response: 200 words unless the user asks for a full explanation.
- Never make up API endpoints or package names.`;

let aiChatHistory = [];

async function sendAIMessage(userMsg, msgsContainer, typingEl) {
  if (!userMsg.trim() || !msgsContainer) return;
  aiChatHistory.push({ role: "user", content: userMsg });
  appendChatBubble(msgsContainer, "user", userMsg);
  if (typingEl) typingEl.style.display = "flex";
  scrollChat(msgsContainer);
  try {
    // Route through Netlify Function — API key stays server-side only
    const res = await fetch("/.netlify/functions/ai-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: userMsg,
        history: aiChatHistory.slice(-10, -1) // send history without the new message
      })
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "API error " + res.status);
    }
    const data  = await res.json();
    const reply = data.reply || "Sorry, I couldn't process that. Please try again.";
    aiChatHistory.push({ role: "assistant", content: reply });
    if (typingEl) typingEl.style.display = "none";
    appendChatBubble(msgsContainer, "ai", reply);
  } catch (err) {
    if (typingEl) typingEl.style.display = "none";
    const errMsg = err.message?.includes("rate") || err.message?.includes("busy")
      ? "⚠️ " + err.message
      : "⚠️ Connection issue. Please check your internet and try again. If the problem persists, reload the page.";
    appendChatBubble(msgsContainer, "ai", errMsg);
  }
  scrollChat(msgsContainer);
}

function appendChatBubble(container, role, text) {
  const wrap   = document.createElement("div");
  wrap.className = `ai-chat-msg ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "chat-bubble";
  bubble.textContent = text;
  wrap.appendChild(bubble);
  container.appendChild(wrap);
}

function scrollChat(container) {
  setTimeout(() => { container.scrollTop = container.scrollHeight; }, 50);
}

function initDashAIChat() {
  const msgsContainer = document.getElementById("aiChatMsgs");
  const inputEl       = document.getElementById("aiChatInput");
  const sendBtn       = document.getElementById("aiChatSend");
  const typingEl      = document.getElementById("aiTyping");
  if (!msgsContainer || !inputEl || !sendBtn) return;

  if (msgsContainer.children.length === 0) {
    appendChatBubble(msgsContainer, "ai",
      "👋 Hi! I'm your eBay Titan AI Mentor.\n\nI can help you set up the bot, understand the code, troubleshoot errors, and answer questions about eBay dropshipping.\n\nWhat do you need help with today?\n\nأنا هنا أيضاً بالعربية — اسألني بأي لغة تريد! 🤖"
    );
  }

  const handleSend = () => {
    const msg = inputEl.value.trim();
    if (!msg) return;
    inputEl.value = "";
    sendAIMessage(msg, msgsContainer, typingEl);
  };

  sendBtn.addEventListener("click", handleSend);
  inputEl.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  });
  document.querySelectorAll(".ai-sugg-btn").forEach(btn => {
    btn.addEventListener("click", () => { inputEl.value = btn.textContent.trim(); handleSend(); });
  });
}

/* ════════════════════════════════════════════════
   FLOATING AI MENTOR WIDGET (public pages)
════════════════════════════════════════════════ */
function injectFloatingAI() {
  const html = `
  <div class="ai-float-widget" id="aiFloatWidget" aria-label="AI Mentor Chat">
    <button class="ai-float-btn" id="aiFloatBtn" aria-haspopup="true" aria-expanded="false" title="Ask AI Mentor">
      <div class="ai-float-icon">🤖</div>
      <div class="ai-float-pulse"></div>
    </button>
    <div class="ai-float-panel glass" id="aiFloatPanel" role="dialog" aria-label="AI Mentor">
      <div class="ai-float-header">
        <div class="ai-float-avatar">🤖</div>
        <div>
          <div class="ai-float-title">eBay Titan AI Mentor</div>
          <div class="ai-float-status"><span class="pulse-dot" style="width:6px;height:6px;margin-right:5px"></span>Online</div>
        </div>
        <button class="ai-float-close" id="aiFloatClose" aria-label="Close">✕</button>
      </div>
      <div class="ai-float-msgs" id="aiFloatMsgs"></div>
      <div class="ai-float-typing" id="aiFloatTyping" style="display:none">
        <span></span><span></span><span></span>
      </div>
      <div class="ai-float-input-row">
        <input type="text" id="aiFloatInput" placeholder="Ask anything about the bot..." autocomplete="off"/>
        <button id="aiFloatSend" class="btn-glow" style="padding:10px 16px;border-radius:9px;font-size:13px;flex-shrink:0">→</button>
      </div>
      <div class="ai-float-chips">
        <button class="ai-sugg-btn" data-q="How do I get eBay API keys?">eBay API keys</button>
        <button class="ai-sugg-btn" data-q="How to create a Telegram bot?">Telegram bot</button>
        <button class="ai-sugg-btn" data-q="The bot runs but sends nothing">Bot not sending</button>
        <button class="ai-sugg-btn" data-q="كيف أشغّل البوت؟">عربي</button>
      </div>
    </div>
  </div>`;

  const wrapper = document.createElement("div");
  wrapper.innerHTML = html;
  document.body.appendChild(wrapper.firstElementChild);

  if (!document.getElementById("ai-float-styles")) {
    const style = document.createElement("style");
    style.id = "ai-float-styles";
    style.textContent = `
      .ai-float-widget{position:fixed;bottom:28px;right:28px;z-index:9000;}
      .ai-float-btn{width:58px;height:58px;border-radius:50%;border:none;cursor:pointer;background:linear-gradient(135deg,#7c3aed,#3b82f6);display:flex;align-items:center;justify-content:center;box-shadow:0 0 30px rgba(124,58,237,.55),0 0 60px rgba(59,130,246,.25);position:relative;transition:transform .3s;}
      .ai-float-btn:hover{transform:scale(1.1);}
      .ai-float-icon{font-size:24px;position:relative;z-index:1;}
      .ai-float-pulse{position:absolute;inset:-4px;border-radius:50%;border:2px solid rgba(124,58,237,.5);animation:pulseGlow 2s infinite;}
      .ai-float-panel{position:absolute;bottom:70px;right:0;width:340px;border-radius:18px;overflow:hidden;display:none;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.7);max-height:480px;}
      .ai-float-panel.open{display:flex;animation:fadeUp .3s ease;}
      .ai-float-header{background:linear-gradient(135deg,rgba(124,58,237,.25),rgba(59,130,246,.15));padding:14px 16px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(124,58,237,.2);}
      .ai-float-avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#3b82f6);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
      .ai-float-title{font-family:'Syne',sans-serif;font-weight:700;font-size:13px;color:#f1f0ff;}
      .ai-float-status{font-size:11px;color:#6ee7b7;display:flex;align-items:center;}
      .ai-float-close{margin-left:auto;background:rgba(255,255,255,.08);border:none;color:#8b87b8;width:26px;height:26px;border-radius:50%;cursor:pointer;font-size:13px;transition:all .2s;}
      .ai-float-close:hover{background:rgba(239,68,68,.2);color:#fca5a5;}
      .ai-float-msgs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px;min-height:160px;max-height:260px;}
      .ai-float-msgs .ai-chat-msg.user{justify-content:flex-end;}
      .ai-float-msgs .ai-chat-msg{display:flex;}
      .ai-float-msgs .chat-bubble{padding:9px 13px;border-radius:12px;font-size:12.5px;line-height:1.65;white-space:pre-wrap;max-width:88%;}
      .ai-float-msgs .ai-chat-msg.user .chat-bubble{background:linear-gradient(135deg,#7c3aed,#3b82f6);color:#fff;border-radius:12px 12px 3px 12px;}
      .ai-float-msgs .ai-chat-msg.ai .chat-bubble{background:rgba(255,255,255,.07);border:1px solid rgba(124,58,237,.2);color:#c4c0e8;border-radius:12px 12px 12px 3px;}
      .ai-float-typing{padding:8px 14px;display:flex;gap:5px;align-items:center;}
      .ai-float-typing span{width:7px;height:7px;border-radius:50%;background:#a78bfa;animation:pulseDot 1.2s infinite;}
      .ai-float-typing span:nth-child(2){animation-delay:.25s;}
      .ai-float-typing span:nth-child(3){animation-delay:.5s;}
      .ai-float-input-row{display:flex;gap:8px;padding:10px 12px;border-top:1px solid rgba(124,58,237,.15);background:rgba(6,6,16,.8);}
      .ai-float-input-row input{flex:1;background:rgba(14,14,30,.9);border:1px solid rgba(124,58,237,.25);border-radius:9px;color:#f1f0ff;font-family:'DM Sans',sans-serif;font-size:13px;padding:9px 13px;outline:none;transition:border-color .3s;}
      .ai-float-input-row input:focus{border-color:#a855f7;}
      .ai-float-input-row input::placeholder{color:#6b6799;}
      .ai-float-chips{display:flex;gap:6px;flex-wrap:wrap;padding:8px 12px 10px;background:rgba(6,6,16,.8);}
      @media(max-width:420px){.ai-float-panel{width:calc(100vw - 20px);right:-8px;}}
    `;
    document.head.appendChild(style);
  }

  const floatBtn    = document.getElementById("aiFloatBtn");
  const floatPanel  = document.getElementById("aiFloatPanel");
  const floatClose  = document.getElementById("aiFloatClose");
  const floatMsgs   = document.getElementById("aiFloatMsgs");
  const floatInput  = document.getElementById("aiFloatInput");
  const floatSend   = document.getElementById("aiFloatSend");
  const floatTyping = document.getElementById("aiFloatTyping");
  let floatHistory  = [];
  let floatOpened   = false;

  floatBtn.addEventListener("click", () => {
    const open = floatPanel.classList.toggle("open");
    floatBtn.setAttribute("aria-expanded", String(open));
    if (open && !floatOpened) {
      floatOpened = true;
      appendChatBubble(floatMsgs, "ai",
        "👋 Hi! I'm the eBay Titan AI Mentor.\nAsk me anything about bot setup, eBay API, Telegram, Python, or errors!\n\nأنا أتكلم العربية أيضاً 🤖"
      );
      scrollChat(floatMsgs);
    }
  });

  floatClose.addEventListener("click", () => {
    floatPanel.classList.remove("open");
    floatBtn.setAttribute("aria-expanded", "false");
  });

  const floatSendHandler = async () => {
    const msg = floatInput.value.trim();
    if (!msg) return;
    floatInput.value = "";
    floatHistory.push({ role: "user", content: msg });
    appendChatBubble(floatMsgs, "user", msg);
    floatTyping.style.display = "flex";
    scrollChat(floatMsgs);
    try {
      // Route through Netlify Function — API key stays server-side only
      const res = await fetch("/.netlify/functions/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msg,
          history: floatHistory.slice(-8, -1)
        })
      });
      const data  = await res.json().catch(() => ({}));
      const reply = data.reply || (res.ok ? "Sorry, try again." : (data.error || "Connection error."));
      floatHistory.push({ role: "assistant", content: reply });
      floatTyping.style.display = "none";
      appendChatBubble(floatMsgs, "ai", reply);
    } catch {
      floatTyping.style.display = "none";
      appendChatBubble(floatMsgs, "ai", "⚠️ Connection error. Please try again.");
    }
    scrollChat(floatMsgs);
  };

  floatSend.addEventListener("click", floatSendHandler);
  floatInput.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); floatSendHandler(); } });
  document.querySelectorAll(".ai-float-chips .ai-sugg-btn").forEach(btn => {
    btn.addEventListener("click", () => { floatInput.value = btn.dataset.q || btn.textContent; floatSendHandler(); });
  });
}
