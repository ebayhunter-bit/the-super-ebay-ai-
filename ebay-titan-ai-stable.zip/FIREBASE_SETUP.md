# eBay Titan AI — Firebase Setup Guide
# Complete walkthrough to go from zero to real auth in 20 minutes

## ⚠️ BEFORE YOU START
This guide sets up **real Firebase Authentication**.
After following it, any email/password will create a real account,
verification emails will be sent by Firebase, and the admin system
will be locked to loordmri428@gmail.com only.

---

## STEP 1 — Create Firebase Project (5 min)

1. Go to **console.firebase.google.com**
2. Click **"Add project"** → name it `ebay-titan-ai`
3. Disable Google Analytics (not needed) → **Create project**
4. Wait ~30 seconds for project creation

---

## STEP 2 — Enable Email/Password Auth (2 min)

1. In Firebase Console → **Build → Authentication**
2. Click **"Get started"**
3. Under **Sign-in providers** → click **Email/Password**
4. Toggle **"Email/Password"** to **Enabled**
5. Leave "Email link (passwordless sign-in)" OFF
6. Click **Save**

---

## STEP 3 — Create Firestore Database (3 min)

1. In Firebase Console → **Build → Firestore Database**
2. Click **"Create database"**
3. Choose **"Production mode"** → click **Next**
4. Select your nearest region (e.g., `europe-west1` for Middle East/EU)
5. Click **Enable**

### Deploy Security Rules

1. Go to **Firestore → Rules tab**
2. Delete the default rule
3. Paste the entire contents of **`firestore.rules`** from your project files
4. Click **Publish**

---

## STEP 4 — Get Your Firebase Config (2 min)

1. In Firebase Console → click the **gear icon** → **Project settings**
2. Scroll down to **"Your apps"** section
3. Click the **Web icon** (`</>`)
4. Register app with nickname `ebay-titan-web` → click **Register app**
5. You'll see a `firebaseConfig` object like this:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXX",
  authDomain: "ebay-titan-ai.firebaseapp.com",
  projectId: "ebay-titan-ai",
  storageBucket: "ebay-titan-ai.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc123def456"
};
```

6. **Copy all values** → open `firebase-config.js` in your project
7. Replace the `FIREBASE_CONFIG` object at the top with your real values

---

## STEP 5 — Create Admin Account (3 min)

The admin account **must be created through Firebase Auth**, not client-side code.

### Option A: Firebase Console (Easiest)

1. Firebase Console → **Authentication → Users**
2. Click **"Add user"**
3. Email: `loordmri428@gmail.com`
4. Password: `Loordmr4`
5. Click **Add user**
6. Note the generated **User UID** (you'll need it)

### Option B: Register via the website

1. Deploy the site (Step 7 below)
2. Go to `login.html` → Create Account tab
3. Register with `loordmri428@gmail.com` / `Loordmr4`
4. Check email for verification link → click it
5. Then manually grant access in Step 6 below

---

## STEP 6 — Set Admin Role in Firestore (2 min)

After creating the admin account, you must set their role and access in Firestore:

1. Firebase Console → **Firestore Database → Data**
2. Click **"Start collection"** → Collection ID: `users`
3. Click **"Auto-ID"** for the document ID — OR use the admin's Firebase UID
4. Add these fields:

```
uid:           (string)  — paste the admin's Firebase UID from Auth → Users
email:         (string)  — loordmri428@gmail.com
firstName:     (string)  — Admin
role:          (string)  — admin
hasAccess:     (boolean) — true
emailVerified: (boolean) — true
createdAt:     (timestamp) — (click "timestamp" type)
loginCount:    (number)  — 0
```

5. Click **Save**

Now Firebase will recognise this user as admin on every sign-in via `titanAuth.isAdmin()`.

---

## STEP 7 — Deploy the Site (5 min)

### Option A: Firebase Hosting (Recommended — free)

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# In your project folder
firebase init hosting

# When asked:
# - Public directory: . (or your site folder)
# - Single-page app: No
# - Overwrite index.html: No

# Deploy
firebase deploy --only hosting
```

Your site will be live at: `https://ebay-titan-ai.web.app`

### Option B: Netlify (Free, drag-and-drop)

1. Go to **netlify.com** → "Add new site" → "Deploy manually"
2. Drag your site folder onto the Netlify upload area
3. Site is live instantly with a free subdomain

### Option C: Any Static Host

Upload all `.html`, `.js`, `.css` files and the `emails/` folder to your hosting provider.

---

## STEP 8 — Configure Email Verification (Firebase default)

Firebase sends verification emails automatically using your project's Firebase domain:
`noreply@YOUR-PROJECT-ID.firebaseapp.com`

**To use a custom "from" email address:**
1. Firebase Console → Authentication → **Templates**
2. Click **"Email address verification"**
3. Customise the subject, body, and sender name

**To use your own domain for sending:**
1. Firebase Console → Authentication → Templates
2. Click the edit icon → **"Customize action URL"**
3. Set it to: `https://your-domain.com/verify-email.html`

---

## STEP 9 — Test Everything

### Test 1: Blocked access without login
Open `dashboard.html` directly in browser → should redirect to `login.html`

### Test 2: Wrong email/password
Try signing in with a random email/password → should show Firebase error

### Test 3: Register + Verify
- Create account with a real email
- Check inbox for verification email
- Click verify link → should redirect to login with success message
- Sign in → if no PayPal payment, should show "no access" error

### Test 4: Admin access
- Sign in as `loordmri428@gmail.com` / `Loordmr4`
- Should redirect to `admin.html`
- Try accessing admin.html as a regular user → should redirect to dashboard

### Test 5: Grant access to a user
- Sign in as admin → admin.html → Users tab
- Find a user → click "Grant" → confirm they can now access dashboard

---

## Payment Integration (PayPal → Grant Access)

When a user pays via PayPal, you need to grant them dashboard access.
Currently this is a **manual process**:

1. User pays at `paypal.me/EsSa799/55`
2. You receive PayPal notification email
3. Sign in to `admin.html` → Users tab
4. Find their email → click **"Grant"**

**For automatic activation**, use the PayPal IPN/webhook setup in `BACKEND_SETUP.md`.
The webhook calls `titanAuth.grantAccess(uid, orderId)` after verifying payment.

---

## Security Summary

| Feature                    | Implementation                      |
|----------------------------|-------------------------------------|
| Password storage           | Firebase — bcrypt internally, never visible |
| Email verification         | Firebase sends real email           |
| Session tokens             | Firebase JWT (auto-refresh)         |
| Route protection           | `titanAuth.requireAuth()` — Firebase `onAuthStateChanged` |
| Admin restriction          | Firestore `role: "admin"` + email check |
| Password reset             | Firebase `sendPasswordResetEmail`   |
| Brute force protection     | Firebase built-in + client rate limiter |
| Database access control    | Firestore security rules            |
| No fake bypass             | All `setTimeout` simulations removed |

---

## Support

**Support email:** ebaysupporthunter@gmail.com
**Admin email (private):** loordmri428@gmail.com

*Keep this file private — do not commit to public repositories.*
