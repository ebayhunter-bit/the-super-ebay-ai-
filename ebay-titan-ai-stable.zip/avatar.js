/**
 * eBay Titan AI — avatar.js
 * Deterministic SVG avatar generator. No external requests.
 * Same name+flag always yields the same face. 500+ unique faces.
 */
"use strict";
(function(global){
  var SKINS=["#FDEBD0","#FDDBB4","#F5C9A0","#EEB98B","#E8A868","#D98E50","#C8855A","#B06B44",
             "#9A5533","#8B4218","#7D3F1F","#6D2F0C","#5C2C0E","#4A1E07","#3D1A0A","#F1C18A",
             "#E0A060","#C47338","#A85A26","#7A4028"];
  var HAIRS=["#0A0A0A","#1C1208","#2C1810","#3D2314","#5C3A1E","#7A4F2E","#9B6B3A","#C19A6B",
             "#D4B896","#E8D5B7","#F5EDD6","#BFBFBF","#8B7355","#6B4535","#4A3020","#C8A060",
             "#E0C080","#F0D8A0"];
  var EYES=[
    function(){return'<circle cx="38" cy="42" r="3.8" fill="#1a1a2e"/><circle cx="62" cy="42" r="3.8" fill="#1a1a2e"/><circle cx="39.5" cy="40.8" r="1.2" fill="#fff"/><circle cx="63.5" cy="40.8" r="1.2" fill="#fff"/>';},
    function(){return'<ellipse cx="38" cy="42" rx="4.5" ry="3.5" fill="#1e3a5f"/><ellipse cx="62" cy="42" rx="4.5" ry="3.5" fill="#1e3a5f"/><circle cx="39" cy="41" r="1.3" fill="#fff"/><circle cx="63" cy="41" r="1.3" fill="#fff"/>';},
    function(){return'<circle cx="38" cy="42" r="3.5" fill="#1a3a1a"/><circle cx="62" cy="42" r="3.5" fill="#1a3a1a"/><circle cx="39" cy="41" r="1" fill="#fff"/><circle cx="63" cy="41" r="1" fill="#fff"/>';},
    function(){return'<ellipse cx="38" cy="42.5" rx="4" ry="3" fill="#2a1a0a"/><ellipse cx="62" cy="42.5" rx="4" ry="3" fill="#2a1a0a"/><circle cx="39" cy="41.5" r="1.1" fill="#fff"/><circle cx="63" cy="41.5" r="1.1" fill="#fff"/>';},
    function(){return'<path d="M34.5 42.5 Q38 38.5 41.5 42.5" stroke="#1a1a2e" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M58.5 42.5 Q62 38.5 65.5 42.5" stroke="#1a1a2e" stroke-width="2.8" fill="none" stroke-linecap="round"/>';},
  ];
  var BROWS=[
    function(h){return'<path d="M33 34 Q38 31 43 33" stroke="'+h+'" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".8"/><path d="M57 33 Q62 31 67 34" stroke="'+h+'" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".8"/>';},
    function(h){return'<rect x="33" y="33" width="10" height="2.5" rx="1.2" fill="'+h+'" opacity=".75"/><rect x="57" y="33" width="10" height="2.5" rx="1.2" fill="'+h+'" opacity=".75"/>';},
    function(h){return'<path d="M34 35 Q38 32 42 34" stroke="'+h+'" stroke-width="2" fill="none" stroke-linecap="round" opacity=".7"/><path d="M58 34 Q62 32 66 35" stroke="'+h+'" stroke-width="2" fill="none" stroke-linecap="round" opacity=".7"/>';},
  ];
  var MOUTHS=[
    '<path d="M38 58 Q50 66 62 58" stroke="#c0777a" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    '<path d="M40 57 Q50 63 60 57" stroke="#c08085" stroke-width="2.2" fill="none" stroke-linecap="round"/>',
    '<path d="M42 59 L50 63 L58 59" stroke="#b87070" stroke-width="2.2" fill="none" stroke-linejoin="round" stroke-linecap="round"/>',
    '<ellipse cx="50" cy="59" rx="7" ry="4.5" fill="#c07080" opacity=".65"/>',
    '<path d="M41 57 Q50 61 59 57" stroke="#b06070" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    '<path d="M40 58 Q50 65 60 58" stroke="#d08090" stroke-width="2.2" fill="none" stroke-linecap="round"/>',
  ];
  var NOSES=[
    '<path d="M47 50 Q50 54 53 50" stroke="#0000001a" stroke-width="1.5" fill="none"/>',
    '<ellipse cx="48" cy="52" rx="2.5" ry="1.8" fill="#0000001a"/><ellipse cx="52" cy="52" rx="2.5" ry="1.8" fill="#0000001a"/>',
    '<path d="M48 50 L50 55 L52 50" stroke="#0000001a" stroke-width="1.3" fill="none" stroke-linecap="round"/>',
  ];
  var HSTYLES=[
    function(c){return'<ellipse cx="50" cy="18" rx="26" ry="18" fill="'+c+'"/><rect x="24" y="18" width="52" height="14" fill="'+c+'"/>';},
    function(c){return'<path d="M24 36 Q20 8 50 6 Q80 8 76 36 Q72 14 50 14 Q28 14 24 36Z" fill="'+c+'"/>';},
    function(c){return'<ellipse cx="50" cy="14" rx="24" ry="14" fill="'+c+'"/><rect x="26" y="14" width="48" height="12" fill="'+c+'"/><path d="M24 26 Q19 42 22 64" stroke="'+c+'" stroke-width="9" fill="none"/><path d="M76 26 Q81 42 78 64" stroke="'+c+'" stroke-width="9" fill="none"/>';},
    function(c){return'<path d="M26 32 Q22 6 50 4 Q78 6 74 32 Q68 12 50 12 Q32 12 26 32Z" fill="'+c+'"/>';},
    function(c){return'<rect x="26" y="10" width="48" height="28" rx="24" fill="'+c+'"/>';},
    function(c){return'<ellipse cx="50" cy="10" rx="22" ry="12" fill="'+c+'"/><path d="M72 22 Q80 38 76 62" stroke="'+c+'" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M28 22 Q20 38 24 62" stroke="'+c+'" stroke-width="8" fill="none" stroke-linecap="round"/>';},
  ];
  function seed(s){var h=0;s=(s||"x");for(var i=0;i<s.length;i++){h=(Math.imul(31,h)+s.charCodeAt(i))|0;}return Math.abs(h)>>>0;}
  function sp(arr,sd,off){return arr[Math.abs((sd*2654435761+(off*40503))|0)%arr.length];}
  function generate(name,flag,skinBias){
    var sd=seed((name||"")+(flag||""));
    var bias=Math.min(skinBias||0,4);
    var rawIdx=Math.abs((sd*1234567)%10);
    var skin=SKINS[Math.min(19,rawIdx+bias*2)];
    var hair=HAIRS[Math.abs((sd*987654)%HAIRS.length)];
    var bg=sp(["#0d0820","#081228","#0a1420","#140820","#0a0a18"],sd,6);
    var acc=sp(["#7c3aed","#3b82f6","#10b981","#f59e0b","#a78bfa","#ec4899"],sd,7);
    return'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">'
      +'<rect width="100" height="100" rx="22" fill="'+bg+'"/>'
      +'<rect width="100" height="100" rx="22" fill="'+acc+'" opacity=".1"/>'
      +'<ellipse cx="50" cy="90" rx="33" ry="24" fill="'+skin+'" opacity=".8"/>'
      +'<rect x="42" y="63" width="16" height="12" rx="5" fill="'+skin+'"/>'
      +'<ellipse cx="50" cy="46" rx="23" ry="25" fill="'+skin+'"/>'
      +sp(HSTYLES,sd,2)(hair)
      +sp(BROWS,sd,8)(hair)
      +sp(EYES,sd,4)()
      +sp(NOSES,sd,3)
      +sp(MOUTHS,sd,5)
      +'</svg>';
  }
  function dataUri(name,flag,skinBias){return"data:image/svg+xml,"+encodeURIComponent(generate(name,flag,skinBias));}
  function img(name,flag,size,cls,skinBias){size=size||34;return'<img src="'+dataUri(name,flag,skinBias)+'" width="'+size+'" height="'+size+'" alt="'+(name||"")+'" class="'+(cls||"av-img")+'" loading="lazy"/>';}
  global.Avatar={generate,dataUri,img};
})(window);
