# eBay Titan AI — Complete Production Backend

## ⚠️ SECURITY NOTICE
**NEVER commit this file or your `.env` to a public repository.**
Add both to `.gitignore` immediately.

---

## Overview

The frontend is complete static HTML/CSS/JS.
This guide gives you the **complete working backend** — every file, every line of code.

Stack: `Node.js 18+ · Express · MongoDB · bcrypt · JWT · Nodemailer · Helmet`

---

## Quick Start

```bash
mkdir ebay-titan-backend && cd ebay-titan-backend
npm init -y
npm install express mongoose bcrypt jsonwebtoken nodemailer \
  express-rate-limit helmet cors dotenv express-validator \
  crypto-js uuid
```

---

## File Structure

```
ebay-titan-backend/
├── server.js
├── .env                      ← NEVER commit
├── .gitignore
├── package.json
├── Procfile
├── models/
│   ├── User.js
│   └── SecurityLog.js
├── routes/
│   ├── auth.js
│   ├── payment.js
│   └── admin.js
├── middleware/
│   ├── authGuard.js
│   ├── rateLimiter.js
│   └── sanitize.js
├── utils/
│   ├── email.js
│   └── tokens.js
└── scripts/
    └── createAdmin.js        ← Run once, then delete
```

---

## .env

```bash
# Server
PORT=3000
NODE_ENV=production
DOMAIN=https://your-domain.com

# Database
MONGODB_URI=mongodb+srv://USERNAME:PASSWORD@cluster.mongodb.net/ebay-titan

# JWT
JWT_SECRET=REPLACE_WITH_64_RANDOM_CHARS_eg_openssl_rand_hex_32
JWT_EXPIRES_IN=30m

# Email — Gmail App Password (NOT your real Gmail password)
EMAIL_FROM=eBay Titan AI <ebaysupporthunter@gmail.com>
GMAIL_USER=ebaysupporthunter@gmail.com
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx

# PayPal
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
PAYPAL_WEBHOOK_ID=your_webhook_id
PAYPAL_PRICE=55.00

# Security
BCRYPT_ROUNDS=12
RATE_LIMIT_MAX=5
RATE_LIMIT_WINDOW_MS=900000

# Admin
ADMIN_EMAIL=loordmri428@gmail.com
```

---

## .gitignore

```
node_modules/
.env
*.log
dist/
.DS_Store
```

---

## package.json

```json
{
  "name": "ebay-titan-backend",
  "version": "1.0.0",
  "description": "eBay Titan AI — Production Backend",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "engines": {
    "node": ">=18.0.0"
  },
  "dependencies": {
    "bcrypt": "^5.1.1",
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.19.2",
    "express-rate-limit": "^7.3.1",
    "express-validator": "^7.1.0",
    "helmet": "^7.1.0",
    "jsonwebtoken": "^9.0.2",
    "mongoose": "^8.4.1",
    "nodemailer": "^6.9.13",
    "uuid": "^9.0.1"
  }
}
```

---

## Procfile

```
web: node server.js
```

---

## server.js

```javascript
'use strict';
require('dotenv').config();

const express    = require('express');
const mongoose   = require('mongoose');
const helmet     = require('helmet');
const cors       = require('cors');
const path       = require('path');

const authRoutes    = require('./routes/auth');
const paymentRoutes = require('./routes/payment');
const adminRoutes   = require('./routes/admin');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Connect to MongoDB ──
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => { console.error('MongoDB error:', err); process.exit(1); });

// ── Security headers ──
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'", "https://fonts.googleapis.com", "https://www.google.com"],
      styleSrc:    ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://fonts.gstatic.com"],
      fontSrc:     ["'self'", "https://fonts.gstatic.com"],
      imgSrc:      ["'self'", "data:", "https:"],
      connectSrc:  ["'self'", "https://api.anthropic.com"],
      frameSrc:    ["'none'"],
      objectSrc:   ["'none'"],
    }
  },
  hsts:            { maxAge: 31536000, includeSubDomains: true, preload: true },
  frameguard:      { action: 'deny' },
  noSniff:         true,
  xssFilter:       true,
  referrerPolicy:  { policy: 'strict-origin-when-cross-origin' },
  permittedCrossDomainPolicies: { permittedPolicies: 'none' }
}));

// ── CORS ──
app.use(cors({
  origin:      process.env.DOMAIN,
  credentials: true,
  methods:     ['GET', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// ── Body parsers ──
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// ── Serve static frontend ──
app.use(express.static(path.join(__dirname, '../ebay-titan-site'), {
  setHeaders: (res, filePath) => {
    // No-cache for auth pages
    if (filePath.includes('dashboard') || filePath.includes('login')) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    }
  }
}));

// ── API Routes ──
app.use('/api/auth',    authRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/admin',   adminRoutes);

// ── Security event log endpoint ──
const SecurityLog = require('./models/SecurityLog');
app.post('/api/security/log', express.json(), async (req, res) => {
  try {
    await SecurityLog.create({
      type:      req.body.type    || 'unknown',
      ip:        req.ip,
      userAgent: req.get('User-Agent'),
      data:      req.body.data   || {},
      timestamp: new Date()
    });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false });
  }
});

// ── Health check ──
app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: Date.now() }));

// ── Catch-all: serve frontend ──
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../ebay-titan-site/index.html'));
});

// ── Global error handler ──
app.use((err, req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => console.log(`🚀 eBay Titan AI backend running on port ${PORT}`));
```

---

## models/User.js

```javascript
'use strict';
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  firstName:   { type: String, trim: true, maxlength: 60 },
  lastName:    { type: String, trim: true, maxlength: 60 },
  email:       { type: String, required: true, unique: true, lowercase: true, trim: true, maxlength: 254 },
  password:    { type: String, required: true, minlength: 8 },
  role:        { type: String, enum: ['user', 'admin'], default: 'user' },
  verified:    { type: Boolean, default: false },
  hasAccess:   { type: Boolean, default: false },
  verifyToken: { type: String },
  verifyExpiry:{ type: Date },
  resetToken:  { type: String },
  resetExpiry: { type: Date },
  paypalId:    { type: String },
  purchasedAt: { type: Date },
  lastLogin:   { type: Date },
  loginCount:  { type: Number, default: 0 },
  createdAt:   { type: Date, default: Date.now },
  updatedAt:   { type: Date, default: Date.now }
}, { versionKey: false });

// Auto-update updatedAt
userSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

// Never return password in JSON responses
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.verifyToken;
  delete obj.resetToken;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
```

---

## models/SecurityLog.js

```javascript
'use strict';
const mongoose = require('mongoose');

const securityLogSchema = new mongoose.Schema({
  type:      { type: String, required: true },
  ip:        { type: String },
  userAgent: { type: String },
  email:     { type: String },
  data:      { type: mongoose.Schema.Types.Mixed },
  timestamp: { type: Date, default: Date.now }
}, { versionKey: false });

// Auto-expire logs after 90 days
securityLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 90 * 24 * 60 * 60 });

module.exports = mongoose.model('SecurityLog', securityLogSchema);
```

---

## middleware/authGuard.js

```javascript
'use strict';
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verify JWT from HttpOnly cookie or Authorization header
async function authGuard(req, res, next) {
  try {
    let token = req.cookies?.titan_token;

    if (!token) {
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.slice(7);
      }
    }

    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user    = await User.findById(decoded.id).select('-password');

    if (!user) return res.status(401).json({ error: 'User not found' });
    if (!user.verified)  return res.status(403).json({ error: 'Email not verified' });
    if (!user.hasAccess) return res.status(403).json({ error: 'No platform access' });

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please sign in again.' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Admin-only guard (use after authGuard)
function adminGuard(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

module.exports = { authGuard, adminGuard };
```

---

## middleware/rateLimiter.js

```javascript
'use strict';
const rateLimit   = require('express-rate-limit');
const SecurityLog = require('../models/SecurityLog');

const loginLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX)        || 5,
  standardHeaders: true,
  legacyHeaders:   false,
  skipSuccessfulRequests: true,
  handler: async (req, res) => {
    // Log brute-force attempt
    try {
      await SecurityLog.create({
        type:      'brute_force_blocked',
        ip:        req.ip,
        email:     req.body?.email || '',
        userAgent: req.get('User-Agent'),
        timestamp: new Date()
      });
    } catch (_) {}
    res.status(429).json({
      error:    'Too many attempts. Please wait 15 minutes.',
      redirect: '/blocked.html?r=rate_limit'
    });
  }
});

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  message: { error: 'Too many registration attempts. Try again later.' }
});

const resetLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: { error: 'Too many reset requests. Try again in an hour.' }
});

module.exports = { loginLimiter, registerLimiter, resetLimiter };
```

---

## middleware/sanitize.js

```javascript
'use strict';

// Strip dangerous patterns from input strings
function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/[<>]/g, '')               // HTML tags
    .replace(/javascript:/gi, '')        // JS injection
    .replace(/on\w+\s*=/gi, '')          // event handlers
    .trim()
    .slice(0, 500);
}

// Check for SQL injection patterns
function hasSQLInjection(str) {
  return /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b|;|--|\/\*|\*\/)/i.test(str);
}

// Express middleware — sanitises req.body strings
function sanitizeBody(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    for (const key of Object.keys(req.body)) {
      if (typeof req.body[key] === 'string') {
        if (hasSQLInjection(req.body[key])) {
          return res.status(400).json({ error: 'Invalid input detected', redirect: '/blocked.html?r=injection' });
        }
        req.body[key] = sanitizeString(req.body[key]);
      }
    }
  }
  next();
}

module.exports = { sanitizeBody, sanitizeString, hasSQLInjection };
```

---

## utils/tokens.js

```javascript
'use strict';
const crypto = require('crypto');

// Generate a cryptographically secure random token
function generateToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

// Generate token expiry date
function expiresIn(hours = 24) {
  return new Date(Date.now() + hours * 60 * 60 * 1000);
}

module.exports = { generateToken, expiresIn };
```

---

## utils/email.js

```javascript
'use strict';
const nodemailer = require('nodemailer');
const fs         = require('fs');
const path       = require('path');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD  // App Password, NOT Gmail password
  }
});

// Verify connection on startup
transporter.verify().then(() => {
  console.log('✅ Email transporter ready');
}).catch(err => {
  console.warn('⚠️  Email transporter error:', err.message);
});

const TEMPLATES = {
  'welcome':               { subject: '🎉 Welcome to eBay Titan AI!',                         file: 'welcome.html'               },
  'purchase-confirmation': { subject: '✅ Payment Confirmed — eBay Titan AI Access Activated', file: 'purchase-confirmation.html' },
  'email-verify':          { subject: '📧 Please verify your eBay Titan AI email',             file: 'email-verify.html'          },
  'password-reset':        { subject: '🔑 Reset your eBay Titan AI password',                  file: 'password-reset.html'        },
  'security-alert':        { subject: '🚨 Security Alert — eBay Titan AI',                     file: 'security-alert.html'        },
  'newsletter':            { subject: '⚡ eBay Titan AI — Platform Update',                    file: 'newsletter.html'            },
};

const EMAIL_DIR = path.join(__dirname, '../emails');

async function sendEmail(to, templateKey, variables = {}) {
  const tmpl = TEMPLATES[templateKey];
  if (!tmpl) throw new Error(`Unknown email template: ${templateKey}`);

  let html = fs.readFileSync(path.join(EMAIL_DIR, tmpl.file), 'utf-8');

  // Replace {{VARIABLE}} placeholders
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`{{${key.toUpperCase()}}}`, 'g');
    html = html.replace(regex, String(value ?? ''));
  }

  // Replace domain placeholder
  html = html.replace(/https:\/\/YOUR_DOMAIN/g, process.env.DOMAIN || 'https://your-domain.com');

  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to,
    subject: tmpl.subject,
    html
  });
}

module.exports = { sendEmail };
```

---

## routes/auth.js

```javascript
'use strict';
const express  = require('express');
const bcrypt   = require('bcrypt');
const jwt      = require('jsonwebtoken');
const router   = express.Router();

const User           = require('../models/User');
const SecurityLog    = require('../models/SecurityLog');
const { sendEmail }  = require('../utils/email');
const { generateToken, expiresIn } = require('../utils/tokens');
const { sanitizeBody }  = require('../middleware/sanitize');
const { loginLimiter, registerLimiter, resetLimiter } = require('../middleware/rateLimiter');
const { authGuard }  = require('../middleware/authGuard');

// ─────────────────────────────────────────────
// POST /api/auth/register
// ─────────────────────────────────────────────
router.post('/register', registerLimiter, sanitizeBody, async (req, res) => {
  try {
    const { firstName, email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email address.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }

    // Check for existing account
    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      // Don't reveal whether the email exists — timing-safe response
      await new Promise(r => setTimeout(r, 400));
      return res.status(200).json({ ok: true, message: 'If that email is available, a verification link has been sent.' });
    }

    // Hash password
    const rounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
    const hash   = await bcrypt.hash(password, rounds);

    // Generate email verification token
    const verifyToken  = generateToken(32);
    const verifyExpiry = expiresIn(24);

    // Create user
    const user = await User.create({
      firstName:   firstName || '',
      email:       email.toLowerCase(),
      password:    hash,
      verifyToken,
      verifyExpiry,
      verified:    false,
      hasAccess:   false
    });

    // Build verify URL
    const verifyUrl = `${process.env.DOMAIN}/verify-email.html?token=${verifyToken}`;

    // Send verification email
    await sendEmail(user.email, 'email-verify', {
      user_name:  user.firstName || 'there',
      verify_url: verifyUrl,
    });

    res.json({ ok: true, message: 'Account created. Check your email to verify your address.' });

  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// ─────────────────────────────────────────────
// POST /api/auth/login
// ─────────────────────────────────────────────
router.post('/login', loginLimiter, sanitizeBody, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    // Find user — deliberately vague on failure to prevent email enumeration
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      await new Promise(r => setTimeout(r, 600)); // Timing protection
      await SecurityLog.create({ type: 'login_unknown_email', ip: req.ip, email });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Check verification
    if (!user.verified) {
      return res.status(403).json({ error: 'Please verify your email before signing in.', code: 'unverified' });
    }

    // Check platform access (must have paid)
    if (!user.hasAccess) {
      return res.status(403).json({ error: 'No platform access. Please purchase to continue.', code: 'no_access' });
    }

    // Compare password (bcrypt)
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      await SecurityLog.create({ type: 'login_wrong_password', ip: req.ip, email });
      await new Promise(r => setTimeout(r, 600));
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Update login stats
    user.lastLogin  = new Date();
    user.loginCount = (user.loginCount || 0) + 1;
    await user.save();

    // Sign JWT
    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '30m' }
    );

    // Set HttpOnly secure cookie
    res.cookie('titan_token', token, {
      httpOnly: true,
      secure:   process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge:   30 * 60 * 1000
    });

    // Send security alert email for new logins
    sendEmail(user.email, 'security-alert', {
      user_name:   user.firstName || 'there',
      event_type:  'New sign-in',
      event_time:  new Date().toUTCString(),
      ip_address:  req.ip,
      location:    'Unknown',
      device:      req.get('User-Agent')?.slice(0, 100) || 'Unknown',
      incident_id: `SEC-${Date.now().toString(36).toUpperCase()}`,
    }).catch(() => {}); // Non-blocking

    res.json({ ok: true, user: { email: user.email, role: user.role, firstName: user.firstName } });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ─────────────────────────────────────────────
// POST /api/auth/logout
// ─────────────────────────────────────────────
router.post('/logout', (req, res) => {
  res.clearCookie('titan_token', { httpOnly: true, secure: true, sameSite: 'strict' });
  res.json({ ok: true });
});

// ─────────────────────────────────────────────
// GET /api/auth/me  — protected
// ─────────────────────────────────────────────
router.get('/me', authGuard, (req, res) => {
  res.json({ ok: true, user: req.user });
});

// ─────────────────────────────────────────────
// GET /api/auth/verify-email?token=...
// ─────────────────────────────────────────────
router.get('/verify-email', async (req, res) => {
  try {
    const { token } = req.query;
    if (!token) return res.status(400).json({ error: 'Missing verification token.' });

    const user = await User.findOne({
      verifyToken:  token,
      verifyExpiry: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({ error: 'Verification link is invalid or has expired.', code: 'expired' });
    }

    user.verified    = true;
    user.hasAccess   = false; // Access granted only after PayPal payment
    user.verifyToken = undefined;
    user.verifyExpiry= undefined;
    await user.save();

    // Send welcome email
    sendEmail(user.email, 'welcome', {
      user_name: user.firstName || 'there',
    }).catch(() => {});

    res.json({ ok: true, message: 'Email verified successfully.' });

  } catch (err) {
    console.error('Verify email error:', err);
    res.status(500).json({ error: 'Verification failed. Please try again.' });
  }
});

// ─────────────────────────────────────────────
// POST /api/auth/forgot-password
// ─────────────────────────────────────────────
router.post('/forgot-password', resetLimiter, sanitizeBody, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required.' });

    const user = await User.findOne({ email: email.toLowerCase() });

    // Always return same response — prevents email enumeration
    const genericResponse = { ok: true, message: 'If an account exists, a reset link has been sent.' };

    if (!user || !user.verified) {
      await new Promise(r => setTimeout(r, 400));
      return res.json(genericResponse);
    }

    const resetToken  = generateToken(32);
    const resetExpiry = expiresIn(2); // 2-hour window

    user.resetToken  = resetToken;
    user.resetExpiry = resetExpiry;
    await user.save();

    const resetUrl = `${process.env.DOMAIN}/reset-password.html?token=${resetToken}`;

    await sendEmail(user.email, 'password-reset', {
      user_name: user.firstName || 'there',
      reset_url: resetUrl,
    });

    res.json(genericResponse);

  } catch (err) {
    console.error('Forgot password error:', err);
    res.status(500).json({ error: 'Request failed. Please try again.' });
  }
});

// ─────────────────────────────────────────────
// POST /api/auth/reset-password
// ─────────────────────────────────────────────
router.post('/reset-password', sanitizeBody, async (req, res) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return res.status(400).json({ error: 'Token and new password are required.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }

    const user = await User.findOne({
      resetToken:  token,
      resetExpiry: { $gt: new Date() }
    });

    if (!user) {
      return res.status(400).json({ error: 'Reset link is invalid or has expired.' });
    }

    const rounds    = parseInt(process.env.BCRYPT_ROUNDS) || 12;
    user.password   = await bcrypt.hash(password, rounds);
    user.resetToken  = undefined;
    user.resetExpiry = undefined;
    await user.save();

    // Notify user of password change
    sendEmail(user.email, 'security-alert', {
      user_name:   user.firstName || 'there',
      event_type:  'Password changed',
      event_time:  new Date().toUTCString(),
      ip_address:  req.ip,
      location:    'Unknown',
      device:      req.get('User-Agent')?.slice(0, 100) || 'Unknown',
      incident_id: `SEC-${Date.now().toString(36).toUpperCase()}`,
    }).catch(() => {});

    res.json({ ok: true, message: 'Password reset successfully. You can now sign in.' });

  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Password reset failed. Please try again.' });
  }
});

module.exports = router;
```

---

## routes/payment.js

```javascript
'use strict';
const express = require('express');
const router  = express.Router();

const User          = require('../models/User');
const SecurityLog   = require('../models/SecurityLog');
const { sendEmail } = require('../utils/email');

// ─────────────────────────────────────────────
// POST /api/payment/verify
// Called from frontend after PayPal redirect
// Body: { orderID, payerEmail }
// ─────────────────────────────────────────────
router.post('/verify', async (req, res) => {
  try {
    const { orderID, payerEmail } = req.body;

    if (!orderID || !payerEmail) {
      return res.status(400).json({ error: 'Missing payment data.' });
    }

    // ── Verify with PayPal Orders API ──
    // Get OAuth token from PayPal
    const credentials = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const tokenRes = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
      method:  'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type':  'application/x-www-form-urlencoded'
      },
      body: 'grant_type=client_credentials'
    });
    const tokenData  = await tokenRes.json();
    const ppToken    = tokenData.access_token;

    // Fetch order details from PayPal
    const orderRes = await fetch(`https://api-m.paypal.com/v2/checkout/orders/${orderID}`, {
      headers: { 'Authorization': `Bearer ${ppToken}` }
    });
    const order = await orderRes.json();

    // Validate order status and amount
    const status = order?.status;
    const amount = parseFloat(order?.purchase_units?.[0]?.amount?.value || '0');
    const expectedAmount = parseFloat(process.env.PAYPAL_PRICE || '55.00');

    if (status !== 'COMPLETED') {
      return res.status(400).json({ error: 'Payment not completed.' });
    }
    if (amount < expectedAmount) {
      await SecurityLog.create({ type: 'payment_wrong_amount', ip: req.ip, data: { amount, orderID } });
      return res.status(400).json({ error: 'Payment amount incorrect.' });
    }

    // ── Grant access ──
    let user = await User.findOne({ email: payerEmail.toLowerCase() });

    if (!user) {
      // Create account for PayPal buyer who isn't registered yet
      const bcrypt = require('bcrypt');
      const { generateToken } = require('../utils/tokens');
      const tempPass = generateToken(16); // Random temp password
      user = await User.create({
        email:       payerEmail.toLowerCase(),
        password:    await bcrypt.hash(tempPass, 12),
        verified:    true,
        hasAccess:   true,
        paypalId:    orderID,
        purchasedAt: new Date()
      });
    } else {
      user.hasAccess   = true;
      user.paypalId    = orderID;
      user.purchasedAt = new Date();
      await user.save();
    }

    // ── Send confirmation emails ──
    await sendEmail(user.email, 'purchase-confirmation', {
      user_name:  user.firstName || 'there',
      order_id:   orderID,
      amount:     amount.toFixed(2),
      date:       new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      dashboard_url: `${process.env.DOMAIN}/dashboard.html`,
    });

    // Notify admin
    sendEmail(process.env.ADMIN_EMAIL, 'purchase-confirmation', {
      user_name:  `ADMIN COPY — new buyer: ${user.email}`,
      order_id:   orderID,
      amount:     amount.toFixed(2),
      date:       new Date().toUTCString(),
      dashboard_url: `${process.env.DOMAIN}/dashboard.html`,
    }).catch(() => {});

    res.json({ ok: true, message: 'Payment verified. Access granted.' });

  } catch (err) {
    console.error('Payment verify error:', err);
    res.status(500).json({ error: 'Payment verification failed. Email ebaysupporthunter@gmail.com with your PayPal receipt.' });
  }
});

// ─────────────────────────────────────────────
// POST /api/payment/webhook
// PayPal IPN / Webhook receiver
// Configure URL in PayPal Developer Dashboard
// ─────────────────────────────────────────────
router.post('/webhook', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    // Acknowledge immediately to prevent PayPal retries
    res.status(200).json({ received: true });

    const body  = JSON.parse(req.body.toString());
    const event = body?.event_type;

    if (event === 'PAYMENT.CAPTURE.COMPLETED' || event === 'CHECKOUT.ORDER.APPROVED') {
      const payerEmail = body?.resource?.payer?.email_address;
      const amount     = parseFloat(body?.resource?.purchase_units?.[0]?.amount?.value || '0');
      const orderID    = body?.resource?.id;
      const expected   = parseFloat(process.env.PAYPAL_PRICE || '55.00');

      if (payerEmail && amount >= expected) {
        const user = await User.findOneAndUpdate(
          { email: payerEmail.toLowerCase() },
          { hasAccess: true, paypalId: orderID, purchasedAt: new Date() },
          { new: true }
        );
        if (user) {
          sendEmail(user.email, 'purchase-confirmation', {
            user_name:    user.firstName || 'there',
            order_id:     orderID,
            amount:       amount.toFixed(2),
            date:         new Date().toLocaleDateString('en-GB'),
            dashboard_url:`${process.env.DOMAIN}/dashboard.html`,
          }).catch(() => {});
        }
      }
    }
  } catch (err) {
    console.error('Webhook error:', err);
  }
});

module.exports = router;
```

---

## routes/admin.js

```javascript
'use strict';
const express = require('express');
const router  = express.Router();

const User        = require('../models/User');
const SecurityLog = require('../models/SecurityLog');
const { authGuard, adminGuard } = require('../middleware/authGuard');

// All admin routes require auth + admin role
router.use(authGuard, adminGuard);

// GET /api/admin/users — list all users
router.get('/users', async (req, res) => {
  try {
    const page  = parseInt(req.query.page)  || 1;
    const limit = parseInt(req.query.limit) || 50;
    const users = await User.find({})
      .select('-password -verifyToken -resetToken')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);
    const total = await User.countDocuments();
    res.json({ ok: true, users, total, page, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users.' });
  }
});

// POST /api/admin/users/:id/grant — grant dashboard access
router.post('/users/:id/grant', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { hasAccess: true, verified: true },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ ok: true, user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to grant access.' });
  }
});

// POST /api/admin/users/:id/revoke — revoke access
router.post('/users/:id/revoke', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { hasAccess: false },
      { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ ok: true, user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to revoke access.' });
  }
});

// DELETE /api/admin/users/:id — delete user
router.delete('/users/:id', async (req, res) => {
  try {
    // Prevent deleting your own admin account
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ error: 'Cannot delete your own account.' });
    }
    await User.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete user.' });
  }
});

// GET /api/admin/security-logs — last 200 security events
router.get('/security-logs', async (req, res) => {
  try {
    const logs = await SecurityLog.find({})
      .sort({ timestamp: -1 })
      .limit(200);
    res.json({ ok: true, logs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch logs.' });
  }
});

// GET /api/admin/stats — platform statistics
router.get('/stats', async (req, res) => {
  try {
    const [totalUsers, verified, withAccess, recent] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ verified: true }),
      User.countDocuments({ hasAccess: true }),
      User.countDocuments({ createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } })
    ]);
    res.json({ ok: true, stats: { totalUsers, verified, withAccess, newThisWeek: recent } });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats.' });
  }
});

module.exports = router;
```

---

## scripts/createAdmin.js

```javascript
/**
 * eBay Titan AI — Create Initial Admin Account
 *
 * Run ONCE:  node scripts/createAdmin.js
 * Then:      DELETE this file or add it to .gitignore
 *
 * NEVER expose admin credentials in client-side code.
 * NEVER commit this file to a public repository.
 */
'use strict';
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt   = require('bcrypt');
const User     = require('../models/User');

async function createAdmin() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to database.');

  const ADMIN_EMAIL = 'loordmri428@gmail.com';
  // Password is read from env — never hardcode in scripts
  const ADMIN_PASS  = process.env.ADMIN_INITIAL_PASSWORD;

  if (!ADMIN_PASS) {
    console.error('ERROR: Set ADMIN_INITIAL_PASSWORD in your .env file, then run this script.');
    process.exit(1);
  }

  const existing = await User.findOne({ email: ADMIN_EMAIL });
  if (existing) {
    console.log('Admin account already exists. No action taken.');
    await mongoose.disconnect();
    return;
  }

  const rounds = parseInt(process.env.BCRYPT_ROUNDS) || 12;
  const hash   = await bcrypt.hash(ADMIN_PASS, rounds);

  await User.create({
    email:       ADMIN_EMAIL,
    password:    hash,
    role:        'admin',
    verified:    true,
    hasAccess:   true,
    createdAt:   new Date()
  });

  console.log(`✅ Admin account created: ${ADMIN_EMAIL}`);
  console.log('');
  console.log('NEXT STEPS:');
  console.log('  1. Remove ADMIN_INITIAL_PASSWORD from your .env file');
  console.log('  2. Delete this script file (scripts/createAdmin.js)');
  console.log('  3. Add scripts/ to .gitignore');
  console.log('');

  await mongoose.disconnect();
}

createAdmin().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
```

> **After running:** Remove `ADMIN_INITIAL_PASSWORD` from `.env`, delete this script, and add `scripts/` to `.gitignore`.

---

## Deployment: Railway.app (Recommended — Free Tier)

```bash
# 1. Install Railway CLI
npm install -g @railway/cli

# 2. Login
railway login

# 3. Initialise project in your backend folder
cd ebay-titan-backend
railway init

# 4. Add ALL environment variables via the Railway Dashboard
#    (Variables tab — never in code)
#    PORT, NODE_ENV, MONGODB_URI, JWT_SECRET, GMAIL_USER,
#    GMAIL_APP_PASSWORD, PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET,
#    PAYPAL_WEBHOOK_ID, PAYPAL_PRICE, DOMAIN, ADMIN_EMAIL,
#    EMAIL_FROM, BCRYPT_ROUNDS

# 5. Deploy
railway up

# 6. Get your deployment URL from the Railway dashboard
#    Set it as DOMAIN in Railway Variables
```

**MongoDB Atlas Free Tier:**
1. Go to cloud.mongodb.com → Create free M0 cluster
2. Database Access → Add user with password
3. Network Access → Allow from anywhere (0.0.0.0/0) for Railway
4. Connect → Get your connection string → paste into `MONGODB_URI`

**Gmail App Password:**
1. myaccount.google.com → Security → 2-Step Verification → ON
2. App Passwords → Generate for "Mail" / "Other (Custom name)"
3. Copy the 16-char password → paste into `GMAIL_APP_PASSWORD`

---

## PayPal Webhook Setup

1. developer.paypal.com → My Apps → Your App → Webhooks
2. Add webhook URL: `https://your-railway-domain.up.railway.app/api/payment/webhook`
3. Select events: `PAYMENT.CAPTURE.COMPLETED`, `CHECKOUT.ORDER.APPROVED`
4. Copy Webhook ID → paste into `PAYPAL_WEBHOOK_ID`

---

## Frontend Integration

Update `login.html` to call the real backend instead of the simulation:

```javascript
// Replace the setTimeout simulation in login.html with:
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include', // sends HttpOnly cookie
  body: JSON.stringify({ email, password })
});
const data = await response.json();
if (data.ok) {
  location.replace('dashboard.html');
} else {
  showError(data.error || 'Login failed.');
}
```

---

## Security Checklist — Before Going Live

- [ ] `.env` is in `.gitignore` and never committed
- [ ] `scripts/createAdmin.js` deleted after first run
- [ ] `ADMIN_INITIAL_PASSWORD` removed from `.env` after admin created
- [ ] `JWT_SECRET` is at least 64 random characters (`openssl rand -hex 32`)
- [ ] `BCRYPT_ROUNDS` is 12 or higher
- [ ] HTTPS enforced on Railway (automatic) or via Nginx
- [ ] PayPal webhook URL is set and verified
- [ ] Email transporter verified (check Railway logs on startup)
- [ ] Rate limiting active on `/api/auth/login` and `/api/auth/register`
- [ ] MongoDB Atlas IP allowlist restricted to Railway IPs (optional, stricter)
- [ ] `NODE_ENV=production` set in Railway variables

---

*eBay Titan AI — Production Backend Guide*
*Keep this file private. Add to `.gitignore`. Never share publicly.*
