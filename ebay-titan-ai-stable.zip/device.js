/**
 * eBay Titan AI — Device Detection & Real-Time Clock
 * =====================================================
 * Loaded on every page. Provides:
 *   - Device type detection (mobile/tablet/desktop)
 *   - Real-time clock widget
 *   - Touch vs mouse interaction mode
 *   - CSS classes on <html> for device-specific styling
 *   - Responsive layout adjustments
 */

"use strict";

/* ════════════════════════════════════════════════
   1. DEVICE DETECTION
════════════════════════════════════════════════ */
const TitanDevice = (function () {

  const UA  = navigator.userAgent;
  const W   = () => window.innerWidth;
  const H   = () => window.innerHeight;

  const isMobilUA   = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(UA);
  const isTabletUA  = /iPad|Android(?!.*Mobile)/i.test(UA);
  const hasTouchAPI = ("ontouchstart" in window) || navigator.maxTouchPoints > 0;

  function getType() {
    const w = W();
    if (w < 480)  return "mobile";
    if (w < 900)  return "tablet";
    return "desktop";
  }

  function getOS() {
    if (/iPhone|iPad|iPod/.test(UA)) return "ios";
    if (/Android/.test(UA))          return "android";
    if (/Windows/.test(UA))          return "windows";
    if (/Mac/.test(UA))              return "mac";
    if (/Linux/.test(UA))            return "linux";
    return "unknown";
  }

  function applyClasses() {
    const type  = getType();
    const root  = document.documentElement;
    // Remove old classes
    root.classList.remove("device-mobile", "device-tablet", "device-desktop",
                          "touch-device", "mouse-device", "os-ios", "os-android",
                          "os-windows", "os-mac", "os-linux");
    root.classList.add(`device-${type}`);
    root.classList.add(hasTouchAPI ? "touch-device" : "mouse-device");
    root.classList.add(`os-${getOS()}`);
    root.dataset.device = type;
  }

  // Reapply on resize
  let _resizeTimer;
  window.addEventListener("resize", () => {
    clearTimeout(_resizeTimer);
    _resizeTimer = setTimeout(applyClasses, 150);
  }, { passive: true });

  // Apply immediately
  applyClasses();

  // Public API
  return {
    get type()     { return getType(); },
    get isMobile() { return getType() === "mobile"; },
    get isTablet() { return getType() === "tablet"; },
    get isDesktop(){ return getType() === "desktop"; },
    get isTouch()  { return hasTouchAPI; },
    get os()       { return getOS(); },
    get width()    { return W(); },
    get height()   { return H(); },
  };
})();

window.TitanDevice = TitanDevice;

/* ════════════════════════════════════════════════
   2. REAL-TIME CLOCK
════════════════════════════════════════════════ */
const TitanClock = (function () {

  let _interval = null;
  const _targets = new Set();

  function formatTime(d, opts = {}) {
    const { showSeconds = true, hour12 = false } = opts;
    const pad = n => String(n).padStart(2, "0");
    const h   = hour12 ? (d.getHours() % 12 || 12) : d.getHours();
    const m   = d.getMinutes();
    const s   = d.getSeconds();
    const ampm= hour12 ? (d.getHours() < 12 ? " AM" : " PM") : "";
    return `${pad(h)}:${pad(m)}${showSeconds ? ":" + pad(s) : ""}${ampm}`;
  }

  function formatDate(d, opts = {}) {
    const { format = "short" } = opts;
    if (format === "full") {
      return d.toLocaleDateString(navigator.language || "en-GB", {
        weekday: "long", day: "numeric", month: "long", year: "numeric"
      });
    }
    return d.toLocaleDateString(navigator.language || "en-GB", {
      day: "numeric", month: "short", year: "numeric"
    });
  }

  function tick() {
    const now = new Date();
    _targets.forEach(({ el, opts }) => {
      if (!document.body.contains(el)) { _targets.delete({ el, opts }); return; }
      const time = formatTime(now, opts);
      const date = opts.showDate ? formatDate(now, opts) : "";
      el.innerHTML = opts.showDate
        ? `<span class="clock-time">${time}</span><span class="clock-date">${date}</span>`
        : `<span class="clock-time">${time}</span>`;
    });
  }

  function start() {
    if (_interval) return;
    tick(); // immediate first render
    _interval = setInterval(tick, 1000);
  }

  function stop() {
    if (_interval) { clearInterval(_interval); _interval = null; }
  }

  /**
   * Mount a clock into a DOM element.
   * @param {string|Element} target — CSS selector or element
   * @param {Object} opts — { showSeconds, hour12, showDate }
   */
  function mount(target, opts = {}) {
    const el = typeof target === "string" ? document.querySelector(target) : target;
    if (!el) return;
    _targets.add({ el, opts });
    start();
    return { unmount: () => _targets.delete({ el, opts }) };
  }

  /**
   * Create and inject a clock widget into the page.
   * Call after DOMContentLoaded.
   */
  function injectWidget(containerId, opts = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const isMob = TitanDevice.isMobile;
    const widget = document.createElement("div");
    widget.className = "clock-widget glass";
    widget.id = "titanClockWidget";
    widget.setAttribute("aria-label", "Current time");
    widget.innerHTML = `
      <div class="clock-icon">🕐</div>
      <div class="clock-content" id="titanClockContent"></div>
    `;
    container.appendChild(widget);

    mount("#titanClockContent", {
      showSeconds: !isMob, // save space on mobile
      hour12:      false,
      showDate:    !isMob,
      ...opts
    });
  }

  return { mount, injectWidget, formatTime, formatDate, stop };
})();

window.TitanClock = TitanClock;

/* ════════════════════════════════════════════════
   3. MOBILE-SPECIFIC ADAPTATIONS
════════════════════════════════════════════════ */
document.addEventListener("DOMContentLoaded", function () {

  const device = TitanDevice;

  // ── Inject real-time clock into dashboard topbar ──
  const dashTopbar = document.querySelector(".dash-topbar");
  if (dashTopbar) {
    const clockWrap = document.createElement("div");
    clockWrap.id = "clockContainer";
    clockWrap.style.cssText = "display:flex;align-items:center;margin-left:auto;flex-shrink:0";
    dashTopbar.appendChild(clockWrap);
    TitanClock.injectWidget("clockContainer");
  }

  // ── Mobile: simplify hover effects to tap ──
  if (device.isTouch) {
    // Add touch-active class on touch start for visual feedback
    document.querySelectorAll(".feat-card, .step-card, .tg-card, .dash-tut-card, .lesson-row").forEach(el => {
      el.addEventListener("touchstart", () => el.classList.add("touch-active"), { passive: true });
      el.addEventListener("touchend",   () => setTimeout(() => el.classList.remove("touch-active"), 200), { passive: true });
    });
  }

  // ── Mobile: auto-collapse sidebar after nav on small screens ──
  if (device.isMobile) {
    document.querySelectorAll(".dash-nav-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const sidebar = document.getElementById("dashSidebar");
        if (sidebar) sidebar.classList.remove("open");
      });
    });
  }

  // ── Desktop: show keyboard shortcuts hint ──
  if (device.isDesktop && !device.isTouch) {
    // Escape closes overlays (already handled in dashboard.html)
    // Add tooltip to tutorial close button
    const closeBtn = document.querySelector(".tut-overlay-close");
    if (closeBtn && !closeBtn.title) {
      closeBtn.title = "Close (Esc)";
    }
  }

  // ── iOS: fix 100vh issue (address bar changes viewport height) ──
  if (device.os === "ios") {
    const setVH = () => {
      document.documentElement.style.setProperty("--vh", `${window.innerHeight * 0.01}px`);
    };
    setVH();
    window.addEventListener("resize", setVH, { passive: true });
  }

  // ── Detect slow connection and disable heavy animations ──
  if (navigator.connection && navigator.connection.saveData) {
    document.documentElement.classList.add("save-data");
  }

  // ── Log device info (removed from production console) ──
  // console.info("[TitanDevice]", device.type, device.os);
});

/* ════════════════════════════════════════════════
   4. INLINE CLOCK WIDGET STYLES
════════════════════════════════════════════════ */
(function injectClockStyles() {
  if (document.getElementById("titan-clock-styles")) return;
  const style = document.createElement("style");
  style.id = "titan-clock-styles";
  style.textContent = `
    /* ── Clock widget ── */
    .clock-widget {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 14px;
      border-radius: 10px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 13px;
      color: var(--text-2, #c4c0e8);
      white-space: nowrap;
      user-select: none;
    }
    .clock-icon {
      font-size: 14px;
      opacity: .7;
    }
    .clock-content {
      display: flex;
      flex-direction: column;
      gap: 1px;
      line-height: 1.2;
    }
    .clock-time {
      color: var(--neon, #a78bfa);
      font-weight: 700;
      letter-spacing: .04em;
      font-size: 13px;
    }
    .clock-date {
      font-size: 10px;
      color: var(--muted, #6b6799);
      letter-spacing: .02em;
    }

    /* ── Device-specific CSS classes ── */
    /* Mobile touch feedback */
    .touch-device .feat-card.touch-active,
    .touch-device .step-card.touch-active,
    .touch-device .dash-tut-card.touch-active {
      transform: scale(0.98);
      transition: transform 0.1s;
    }
    .touch-device .lesson-row.touch-active {
      background: rgba(124,58,237,.12);
    }

    /* Hide hover tooltips on touch devices */
    .touch-device .tooltip { display: none !important; }

    /* Desktop: cursor pointer on interactive elements */
    .mouse-device .feat-card,
    .mouse-device .step-card,
    .mouse-device .dash-tut-card,
    .mouse-device .lesson-row { cursor: pointer; }

    /* iOS full-height fix */
    :root { --vh: 1vh; }
    .ios-full-height { height: calc(var(--vh, 1vh) * 100); }

    /* Save data mode — reduce animations */
    .save-data *, .save-data *::before, .save-data *::after {
      animation-duration: .01ms !important;
      transition-duration: .01ms !important;
    }

    /* Mobile: larger touch targets */
    .device-mobile .btn-glow,
    .device-mobile .btn-ghost {
      min-height: 44px;
      padding-top: 12px;
      padding-bottom: 12px;
    }
    .device-mobile .dash-nav-btn {
      min-height: 48px;
      padding: 14px 18px;
    }
    .device-mobile .auth-input {
      min-height: 48px;
      font-size: 16px; /* prevents iOS zoom on focus */
    }
    .device-mobile .faq-q {
      min-height: 52px;
      padding: 16px 20px;
    }

    /* Tablet: balanced layout */
    .device-tablet .dash-stats {
      grid-template-columns: repeat(2, 1fr);
    }
    .device-tablet .dash-tut-grid {
      grid-template-columns: repeat(2, 1fr);
    }
    .device-tablet .clock-widget .clock-date { display: none; }

    /* Mobile: compact clock */
    .device-mobile .clock-widget {
      padding: 5px 10px;
      font-size: 11.5px;
    }
    .device-mobile .clock-widget .clock-date { display: none; }
    .device-mobile .clock-widget .clock-icon { display: none; }

    /* Desktop: full clock */
    .device-desktop .clock-widget {
      padding: 8px 16px;
    }
  `;
  document.head.appendChild(style);
})();
