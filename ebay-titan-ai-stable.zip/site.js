/**
 * eBay Titan AI — site.js
 * ========================
 * Unified live experience engine.
 * Canvas particles · Ticker · Live counters · AI terminal
 * Activity feed · Review wall · Popup notifications · Micro-interactions
 *
 * Architecture: single IIFE, no globals polluted, no dependencies.
 */
"use strict";

(function () {

  /* ─── RNG ─────────────────────────────────────────── */
    let _s = ((Date.now() ^ 0xDEADBEEF) ^ (Math.random()*0xFFFFFFFF|0)) >>> 0;
  function rng() { _s ^= _s << 13; _s ^= _s >>> 17; _s ^= _s << 5; return (_s >>> 0) / 4294967296; }
  function ri(a, b) { return Math.floor(rng() * (b - a + 1)) + a; }
  function pick(arr) { return arr[ri(0, arr.length - 1)]; }
  function pickW(arr, wts) { var t=0; for(var i=0;i<wts.length;i++)t+=wts[i]; var r=rng()*t; for(var i=0;i<arr.length;i++){r-=wts[i];if(r<=0)return arr[i];} return arr[arr.length-1]; }

  /* ─── DATA ────────────────────────────────────────── */
  /* ─── 500+ names · 30 countries · 100+ cities (combinatorial) ─── */
  const NP = {
    us:["Michael","Tyler","Daniel","Olivia","Nathan","Jake","Ryan","Ashley","Brandon","Samantha","Chris","Jessica","Kevin","Amy","Justin","Melissa","Brian","Lauren","Eric","Stephanie","Josh","Nicole","Matt","Amanda","Derek","Sarah","Zach","Scott","Alex","Jordan","Cameron","Taylor","Morgan","Riley","Avery","Connor","Hannah","Mason","Logan","Luke","Emma","Lily","Lucas","Hunter","Ethan","Isabella","Aiden","Natalie","Dylan","Owen","Chloe","Max","Caleb","Madison","Ben","Grace","Adam","Mia","Jason","Sophia","Noah"],
    ca:["Emma","Rachel","Liam","Ethan","Madison","Logan","Avery","Owen","Grace","Lucas","Chloe","Carter","Mason","Charlotte","Aiden","Harper","Finn","Brooklyn"],
    gb:["James","Sophie","George","Isla","Harry","Rosie","Charlie","Freya","Jack","Alice","Oliver","Ella","William","Mia","Thomas","Alfie","Amelia","Archie","Oscar","Evie","Leo"],
    ie:["Patrick","Caitlin","Sean","Aoife","Declan","Sinead","Ronan","Ciara","Brendan"],
    de:["Lukas","Hannah","Maximilian","Laura","Tobias","Anna","Florian","Lena","Stefan","Julia","Markus","Lea","Simon","Felix","Niklas","Jana","Leon","Sophia","Jonas","Lisa"],
    fr:["Antoine","Camille","Nicolas","Lucie","Pierre","Marie","Julien","Emma","Thomas","Mathilde","Hugo","Clara","Alexis","Manon","Lucas","Charlotte","Théo","Lola","Romain"],
    es:["Carlos","Sofia","Alejandro","Lucia","Pablo","Maria","Jorge","Ana","Miguel","Isabella","Javier","Carmen","Antonio","Elena","Diego","Marta","Alvaro","Adrian"],
    it:["Matteo","Giulia","Marco","Valentina","Luca","Chiara","Davide","Federica","Andrea","Martina","Lorenzo","Elisa","Simone","Sara","Giuseppe","Francesca","Alessandro"],
    nl:["Sander","Lisa","Daan","Emma","Bram","Anouk","Lars","Sofie","Jelle","Floor","Niels","Lotte"],
    se:["Felix","Maja","Oscar","Elsa","Lucas","Alicia","Axel","Wilma","William","Elin","Viktor"],
    no:["Lars","Ingrid","Erik","Astrid","Bjorn","Freya","Tor","Sven","Greta","Sigrid"],
    dk:["Mikkel","Emma","Rasmus","Sofie","Christian","Anders","Jakob","Ida","Frederik"],
    pl:["Piotr","Anna","Marcin","Katarzyna","Tomasz","Agnieszka","Marek","Karolina","Rafal"],
    sa:["Ahmed","Fatima","Mohammed","Noura","Abdullah","Sara","Khalid","Lama","Omar","Reem","Sultan","Faisal","Turki","Haya","Bandar","Faris","Saleh","Majed","Nawaf","Abdulaziz"],
    ae:["Omar","Mariam","Hamdan","Saeed","Rashid","Zayed","Amira","Latifa","Shamma","Alia","Mansoor"],
    eg:["Yasmin","Mohamed","Nadia","Karim","Dina","Tarek","Rania","Hossam","Sherif","Ahmad","Mona"],
    kw:["Khaled","Dalal","Waleed","Jasem","Fawaz","Maha","Noura","Bader","Yousef"],
    jo:["Nour","Ahmad","Lina","Tariq","Rima","Hana","Yousef","Rana","Ziad"],
    ma:["Fatima","Youssef","Zineb","Omar","Amina","Mehdi","Hamza","Karim","Nadia"],
    il:["Yossi","Noa","Avi","Maya","Itai","Shira","Tal","Yael","Dani","Liron","Mor","Amir"],
    in:["Priya","Rahul","Anita","Vikram","Kavya","Arjun","Deepa","Rohan","Nisha","Amit","Pooja"],
    jp:["Saki","Yuto","Hana","Daiki","Yuki","Ren","Mio","Sota","Aoi","Kenta","Haruto","Sakura"],
    kr:["Jiyeon","Minjun","Sooji","Hyunwoo","Yuna","Junho","Seoa","Taehyun","Jisoo","Jimin"],
    au:["James","Chloe","Jack","Olivia","Liam","Ava","Noah","Sophie","Ethan","Amelia","Cooper","Isla"],
    sg:["Wei","Xin","Jun","Hui","Ming","Ling","Zhi","Yan","Kai","Mei"],
    br:["Isabella","Gabriel","Valentina","Pedro","Beatriz","Matheus","Julia","Lucas","Camila","Rafael"],
    ar:["Diego","Valentina","Matias","Nicolas","Catalina","Lucia","Florencia","Agustin"],
    mx:["Sofia","Miguel","Fernanda","Carlos","Valeria","Jose","Guadalupe","Eduardo"],
    tr:["Mehmet","Ayse","Mustafa","Fatma","Ahmet","Zeynep","Ali","Emine","Hasan","Elif"],
  };
  const LC = {
    us:["Austin","Houston","Phoenix","Dallas","San Jose","Seattle","Denver","Nashville","Atlanta","Portland","Miami","Boston","Chicago","Las Vegas","Charlotte","San Francisco","Detroit","Orlando"],
    ca:["Toronto","Vancouver","Montreal","Calgary","Edmonton","Ottawa","Winnipeg","Halifax"],
    gb:["London","Manchester","Birmingham","Leeds","Glasgow","Liverpool","Edinburgh","Bristol","Cardiff"],
    ie:["Dublin","Cork","Galway","Limerick"],
    de:["Berlin","Munich","Hamburg","Frankfurt","Stuttgart","Cologne","Dresden","Leipzig"],
    fr:["Paris","Lyon","Marseille","Toulouse","Nice","Bordeaux","Strasbourg","Lille"],
    es:["Madrid","Barcelona","Valencia","Seville","Bilbao","Malaga","Granada"],
    it:["Milan","Rome","Naples","Turin","Florence","Bologna","Venice"],
    nl:["Amsterdam","Rotterdam","The Hague","Utrecht","Eindhoven"],
    se:["Stockholm","Gothenburg","Malmö","Uppsala"],
    no:["Oslo","Bergen","Trondheim","Stavanger"],
    dk:["Copenhagen","Aarhus","Odense"],
    pl:["Warsaw","Krakow","Wroclaw","Poznan","Gdansk"],
    sa:["Riyadh","Jeddah","Mecca","Dammam","Khobar","Tabuk","Medina"],
    ae:["Dubai","Abu Dhabi","Sharjah","Ajman"],
    eg:["Cairo","Alexandria","Giza","Luxor"],
    kw:["Kuwait City","Hawalli","Salmiya"],
    jo:["Amman","Irbid","Aqaba"],
    ma:["Casablanca","Rabat","Marrakech","Fez","Tangier"],
    il:["Tel Aviv","Jerusalem","Haifa","Netanya"],
    in:["Mumbai","Delhi","Bangalore","Hyderabad","Chennai","Pune"],
    jp:["Tokyo","Osaka","Yokohama","Nagoya","Sapporo","Kyoto"],
    kr:["Seoul","Busan","Incheon","Daegu"],
    au:["Sydney","Melbourne","Brisbane","Perth","Adelaide","Gold Coast"],
    sg:["Singapore"],
    br:["São Paulo","Rio de Janeiro","Brasília","Salvador","Belo Horizonte"],
    ar:["Buenos Aires","Córdoba","Rosario","Mendoza"],
    mx:["Mexico City","Guadalajara","Monterrey","Puebla"],
    tr:["Istanbul","Ankara","Izmir","Bursa","Antalya"],
  };
  const FL = {us:"🇺🇸",ca:"🇨🇦",gb:"🇬🇧",ie:"🇮🇪",de:"🇩🇪",fr:"🇫🇷",es:"🇪🇸",it:"🇮🇹",nl:"🇳🇱",se:"🇸🇪",no:"🇳🇴",dk:"🇩🇰",pl:"🇵🇱",sa:"🇸🇦",ae:"🇦🇪",eg:"🇪🇬",kw:"🇰🇼",jo:"🇯🇴",ma:"🇲🇦",il:"🇮🇱",in:"🇮🇳",jp:"🇯🇵",kr:"🇰🇷",au:"🇦🇺",sg:"🇸🇬",br:"🇧🇷",ar:"🇦🇷",mx:"🇲🇽",tr:"🇹🇷"};
  const CK = Object.keys(FL);
  const CW = [30,12,18,4,14,10,8,7,6,8,4,4,5,20,16,12,6,6,8,10,12,10,8,8,7,8,6,6,5];
  const SKIN_BIAS = {us:0,ca:0,gb:0,ie:0,de:0,fr:0,es:1,it:1,nl:0,se:0,no:0,dk:0,pl:0,sa:5,ae:5,eg:6,kw:5,jo:5,ma:6,il:3,in:7,jp:3,kr:3,au:0,sg:8,br:4,ar:2,mx:5,tr:4};
  function genMember() {
    var cc = pickW(CK, CW);
    var ns = NP[cc]||NP.us, ls = LC[cc]||[cc.toUpperCase()];
    return { n:pick(ns), f:FL[cc]||"🌍", c:pick(ls), cc:cc, sb:SKIN_BIAS[cc]||0 };
  }

  const NICHE_NAMES = ["Health","Pets","Auto","Office","Fitness","Kitchen","Decor","Garden"];
  const ACT_TEMPLATES = [
    m => `${m.f} <b>${m.n}</b> from ${m.c} found a 🔥 winner`,
    m => `${m.f} <b>${m.n}</b> from ${m.c} upgraded to Pro 👑`,
    m => `${m.f} <b>${m.n}</b> received a Telegram alert`,
    m => `${m.f} Bot sent ${ri(2,9)} alerts to <b>${m.n}</b>`,
    m => `${m.f} <b>${m.n}</b> completed setup in ${ri(20,60)} min`,
    m => `${m.f} <b>${m.n}</b> from ${m.c} just joined ✨`,
    m => `${m.f} <b>${m.n}</b> unlocked Premium 💎`,
    m => `${m.f} <b>${m.n}</b> is scanning ${pick(NICHE_NAMES)} niche`,
    m => `${m.f} <b>${m.n}</b> deployed bot to Railway ☁️`,
    m => `${m.f} <b>${m.n}</b> connected Telegram channel`,
    m => `${m.f} <b>${m.n}</b> exported a report 📊`,
    m => `${m.f} <b>${m.n}</b> ran ${ri(22,68)} AI scans this hour`,
    m => `${m.f} <b>${m.n}</b> found a 💎 low-competition gem`,
    m => `${m.f} <b>${m.n}</b> listed a product — sold in ${ri(2,18)}h 🎉`,
  ];

  const POPUP_TEMPLATES = [
    m => `${m.f} <b>${m.n}</b> from ${m.c} just joined Titan AI`,
    m => `${m.f} <b>${m.n}</b> from ${m.c} found a 🔥 winner`,
    m => `${m.f} <b>${m.n}</b> upgraded to Pro 👑`,
    m => `${m.f} <b>${m.n}</b>'s bot sent ${ri(3,8)} alerts today`,
    m => `${m.f} <b>${m.n}</b> deployed on Railway ☁️`,
    m => `${m.f} <b>${m.n}</b> unlocked Premium 💎`,
    m => `${m.f} <b>${m.n}</b> hit $${ri(3,14)*100} this week`,
    m => `${m.f} <b>${m.n}</b> connected Telegram`,
    m => `${m.f} <b>${m.n}</b> sold an item in ${ri(2,18)}h 🎉`,
    m => `${m.f} <b>${m.n}</b> completed the Academy`,
  ];

  const TICKER_ITEMS = [
    { tier:"🔥 ULTRA WINNER", color:"#f59e0b", name:"Electric Posture Belt Pro",    score:94 },
    { tier:"⚡ FIRE",          color:"#ef4444", name:"Auto Dog Water Fountain",      score:87 },
    { tier:"🔥 ULTRA WINNER", color:"#f59e0b", name:"Magnetic Dashboard Mount",     score:91 },
    { tier:"🔥 HOT NOW",      color:"#a78bfa", name:"LED Desk Lamp Wireless",       score:82 },
    { tier:"⚡ FIRE",          color:"#ef4444", name:"EV Car Charger Organizer",     score:88 },
    { tier:"🔥 ULTRA WINNER", color:"#f59e0b", name:"Pet Self-Grooming Brush",      score:90 },
    { tier:"💎 GEM",           color:"#10b981", name:"Silicone Food Lids 6-Pack",    score:79 },
    { tier:"🔥 HOT NOW",      color:"#a78bfa", name:"Cable Management Tray",        score:86 },
    { tier:"📈 TRENDING",     color:"#3b82f6", name:"Smart LED Strip App Control",  score:77 },
    { tier:"⚡ FIRE",          color:"#ef4444", name:"Resistance Band Set",          score:84 },
  ];

  const TERM_LINES = [
    { t:"[TITAN] OAuth token refreshed. Session valid 7200s.",         c:"#6ee7b7" },
    { t:"[TITAN] Scanning keyword: posture corrector...",              c:null      },
    { t:"[TITAN] 50 items fetched · EXTENDED fieldgroups applied.",    c:null      },
    { t:"[TITAN] VERO filter: 1 blocked (Xiaomi brand).",             c:"#fbbf24" },
    { t:"[TITAN] ⚡ FIRE — Electric Posture Belt Pro · score: 87",     c:"#ef4444" },
    { t:"[TITAN] Telegram alert → 3 channels · delivered.",            c:"#6ee7b7" },
    { t:"[TITAN] Scanning keyword: pet grooming brush...",             c:null      },
    { t:"[TITAN] 🔥 ULTRA WINNER — Pet Brush Pro · score: 94",        c:"#f59e0b" },
    { t:"[TITAN] ✓ 891 watching · Alert sent.",                        c:"#6ee7b7" },
    { t:"[TITAN] Scanning keyword: car accessories...",                c:null      },
    { t:"[TITAN] HOT — Magnetic Mount · score: 91",                   c:"#a78bfa" },
    { t:"[TITAN] ✓ Next scan in 5 min. System healthy.",              c:"#6ee7b7" },
  ];

  const NICHES = [
    { label:"Health & Posture", pct:91, color:"#a78bfa" },
    { label:"Pet Accessories",  pct:84, color:"#3b82f6" },
    { label:"Car Accessories",  pct:88, color:"#f59e0b" },
    { label:"Home Office",      pct:79, color:"#10b981" },
    { label:"Kitchen Gadgets",  pct:76, color:"#ef4444" },
    { label:"Fitness Gear",     pct:82, color:"#60a5fa" },
  ];

  const REVIEWS = [
    { init:"M", name:"Mohammed A.", flag:"🇸🇦", sb:5, stars:5, earn:"$2,400/mo", text:"Bot found 3 winners in first hour. Made $180 profit in one week.", role:"eBay Dropshipper" },
    { init:"J", name:"James K.",    flag:"🇬🇧", sb:0, stars:5, earn:"$1,800/mo", text:"Zero coding. Bot running in one afternoon. Worth every penny.", role:"Part-Time Seller" },
    { init:"S", name:"Sarah M.",    flag:"🇨🇦", sb:0, stars:5, earn:"$1,200/mo", text:"VERO filter saved my account. AI mentor answers instantly.", role:"eBay PowerSeller" },
    { init:"L", name:"Lucas B.",    flag:"🇩🇪", sb:0, stars:5, earn:"$2,100/mo", text:"Deployed to Railway in 30 min. Alerts while I sleep. Best $49.", role:"Full-Time Dropshipper" },
    { init:"E", name:"Emma T.",     flag:"🇦🇺", sb:0, stars:5, earn:"$950/mo",  text:"Found first VERO-safe winner in 20 min. Works perfectly.", role:"Side Hustle Seller" },
    { init:"خ", name:"خالد ح.",     flag:"🇦🇪", sb:5, stars:5, earn:"$4,500/mo", text:"البوت شغال 24/7. استثمار ممتاز بكل المقاييس.", role:"تاجر إلكتروني" },
    { init:"D", name:"Daniel R.",   flag:"🇺🇸", sb:0, stars:5, earn:"$1,650/mo", text:"AI scoring cuts through the noise. Only real opportunities reach me.", role:"eBay PowerSeller" },
    { init:"S", name:"Sophie L.",   flag:"🇫🇷", sb:0, stars:5, earn:"$1,100/mo", text:"Competition analysis alone saves me hours every single week.", role:"Part-Time Seller" },
    { init:"Y", name:"Yuki T.",     flag:"🇯🇵", sb:3, stars:5, earn:"$1,400/mo", text:"Alerts arrive before products trend. Always one step ahead now.", role:"Trend Arbitrageur" },
    { init:"A", name:"Arjun P.",    flag:"🇮🇳", sb:7, stars:5, earn:"$890/mo",  text:"Started with zero experience. First sale within 4 days of joining.", role:"New Dropshipper" },
  ];

  /* ─── State ──────────────────────────────────────── */
  let _scanned = ri(11200, 13400), _online = ri(280, 380), _winners = ri(54, 88);
  let _soundOn = false, _audioCtx = null;
  let _termIdx = 0, _charIdx = 0, _termLine = null;
  let _popupWrap = null;

  /* ─── Helpers ─────────────────────────────────────── */
  function $id(id) { return document.getElementById(id); }
  function setText(id, val) { const el = $id(id); if (el) el.textContent = val; }
  function animNum(el, to, dur) {
    if (!el) return;
    const from = parseInt(el.textContent.replace(/,/g,"")) || 0;
    if (from === to) return;
    const d = to - from, t0 = performance.now();
    (function step(now) {
      const p = Math.min((now - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(from + d * e).toLocaleString();
      if (p < 1) requestAnimationFrame(step);
    })(performance.now());
  }

  /* ─── Canvas background ───────────────────────────── */
  function initCanvas() {
    const canvas = document.createElement("canvas");
    canvas.id = "bgCanvas"; canvas.setAttribute("aria-hidden","true");
    document.body.insertBefore(canvas, document.body.firstChild);
    const ctx = canvas.getContext("2d");
    let W, H, dpr;

    function resize() {
      dpr = Math.min(window.devicePixelRatio||1, 2);
      W = window.innerWidth; H = window.innerHeight;
      canvas.width = W*dpr; canvas.height = H*dpr;
      canvas.style.width = W+"px"; canvas.style.height = H+"px";
      ctx.setTransform(dpr,0,0,dpr,0,0);
    }
    resize();
    window.addEventListener("resize", resize, { passive:true });

    /* Particles */
    const count = W < 768 ? 40 : 72;
    const particles = Array.from({length:count}, () => ({
      x:rng()*W, y:rng()*H,
      vx:(rng()-.5)*.35, vy:(rng()-.5)*.28,
      r:rng()*1.4+.4,
      a:rng()*.35+.08,
      col:["124,58,237","59,130,246","167,139,250"][ri(0,2)],
    }));

    /* City connections */
    const CITIES = [
      [.82,.34],[.48,.27],[.60,.42],[.87,.72],[.87,.35],
      [.79,.54],[.51,.26],[.49,.28],[.58,.40],[.76,.30],
    ];
    const LINKS = [[0,1],[0,4],[1,2],[1,3],[1,7],[2,8],[3,4],[5,4],[6,1],[9,0]];
    const packets = [];
    const rings = [];
    let frameId;

    setInterval(() => {
      const c = CITIES[ri(0,CITIES.length-1)];
      rings.push({x:c[0]*W,y:c[1]*H,r:0,max:55,a:1});
    }, 2200);
    setInterval(() => {
      const [ai,bi] = LINKS[ri(0,LINKS.length-1)];
      const a = CITIES[ai], b = CITIES[bi];
      packets.push({ax:a[0],ay:a[1],bx:b[0],by:b[1],t:rng(),sp:.004+rng()*.005});
    }, 700);

    function draw() {
      frameId = requestAnimationFrame(draw);
      if (document.hidden) return;
      ctx.clearRect(0,0,W,H);

      // Particles
      particles.forEach(p => {
        p.x+=p.vx; p.y+=p.vy;
        if(p.x<-5)p.x=W+5; if(p.x>W+5)p.x=-5;
        if(p.y<-5)p.y=H+5; if(p.y>H+5)p.y=-5;
        ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
        ctx.fillStyle=`rgba(${p.col},${p.a})`; ctx.fill();
      });

      // City links
      LINKS.forEach(([ai,bi]) => {
        const a=CITIES[ai], b=CITIES[bi];
        ctx.beginPath(); ctx.moveTo(a[0]*W,a[1]*H); ctx.lineTo(b[0]*W,b[1]*H);
        ctx.strokeStyle="rgba(124,58,237,.12)"; ctx.lineWidth=.6; ctx.stroke();
      });

      // Packets
      for(let i=packets.length-1;i>=0;i--) {
        const p=packets[i]; p.t+=p.sp;
        if(p.t>=1){packets.splice(i,1);continue;}
        const x=(p.ax+(p.bx-p.ax)*p.t)*W, y=(p.ay+(p.by-p.ay)*p.t)*H;
        ctx.beginPath(); ctx.arc(x,y,2.2,0,Math.PI*2);
        ctx.fillStyle=`rgba(167,139,250,${1-p.t*.5})`;
        ctx.shadowColor="rgba(167,139,250,.7)"; ctx.shadowBlur=7;
        ctx.fill(); ctx.shadowBlur=0;
      }

      // City nodes
      CITIES.forEach(c => {
        const cx=c[0]*W, cy=c[1]*H;
        ctx.beginPath(); ctx.arc(cx,cy,3,0,Math.PI*2);
        ctx.fillStyle="rgba(167,139,250,.75)"; ctx.fill();
      });

      // Rings
      for(let i=rings.length-1;i>=0;i--) {
        const r=rings[i]; r.r+=1.1; r.a=1-r.r/r.max;
        if(r.a<=0){rings.splice(i,1);continue;}
        ctx.beginPath(); ctx.arc(r.x,r.y,r.r,0,Math.PI*2);
        ctx.strokeStyle=`rgba(124,58,237,${r.a*.45})`; ctx.lineWidth=1; ctx.stroke();
      }
    }
    draw();
    document.addEventListener("visibilitychange", () => { if(!document.hidden && !frameId) draw(); });
  }

  /* ─── Ticker ─────────────────────────────────────── */
  function initTicker() {
    const track = $id("tickerTrack");
    if (!track) return;
    const items = [...TICKER_ITEMS, ...TICKER_ITEMS];
    track.innerHTML = items.map(t =>
      `<span class="ticker-item">` +
      `<span class="ticker-tier" style="color:${t.color}">${t.tier}</span>` +
      `<span class="ticker-product">${t.name}</span>` +
      `<span class="ticker-score" style="color:${t.color}">·${t.score}</span>` +
      `<span class="ticker-tsep">—</span>` +
      `</span>`
    ).join("");

    const btn = $id("tickerSound");
    if (btn) btn.addEventListener("click", toggleSound);
  }

  /* ─── Live counters ───────────────────────────────── */
  function initCounters() {
    function tick() {
      _scanned += ri(4, 14);
      _online   = Math.max(180, Math.min(440, _online + ri(-4, 7)));
      _winners += Math.random()<.3?1:0;
      const pairs = [["tickerScanned",_scanned],["tickerOnline",_online],
                   ["intScanned",_scanned],["intOnline",_online],["intWinners",_winners]];
      pairs.forEach(([id,v]) => animNum($id(id), v, 850));
      animNum($id("liveCount"), _winners, 850);
    }
    // Fast micro-tick (silent, no animation) every 2s for constant visible movement
    function micro() {
      _scanned += ri(1, 4);
      _online   = Math.max(180, Math.min(440, _online + ri(-1, 2)));
      setText("tickerScanned", _scanned.toLocaleString());
      setText("tickerOnline", _online.toLocaleString());
      setText("intScanned", _scanned.toLocaleString());
    }
    tick();
    setInterval(micro, 2000);
    setInterval(tick, 4800);
  }

  /* ─── AI Terminal ────────────────────────────────── */
  function initTerminal() {
    const container = $id("termLines");
    if (!container) return;
    function typeNext() {
      const entry = TERM_LINES[_termIdx % TERM_LINES.length];
      if (_charIdx === 0) {
        _termLine = document.createElement("div");
        _termLine.className = "term-line";
        if (entry.c) _termLine.style.color = entry.c;
        container.appendChild(_termLine);
        if (container.children.length > 10) container.firstChild.remove();
      }
      if (_charIdx < entry.t.length) {
        _termLine.textContent = entry.t.slice(0, _charIdx+1);
        _charIdx++;
        setTimeout(typeNext, ri(16,38));
      } else {
        _charIdx=0; _termIdx++;
        const next = TERM_LINES[_termIdx % TERM_LINES.length];
        const pause = (next.t.includes("[TITAN] Scan") ? 480 : 180) + ri(0,120);
        setTimeout(typeNext, pause);
        container.scrollTop = container.scrollHeight;
      }
    }
    setTimeout(typeNext, 700);
  }

  /* ─── Niche heat map ─────────────────────────────── */
  function initNicheHeat() {
    const el = $id("nicheHeat");
    if (!el) return;
    el.innerHTML = NICHES.map(n =>
      `<div class="heat-row">` +
      `<div class="heat-label">${n.label}</div>` +
      `<div class="heat-track"><div class="heat-fill" data-w="${n.pct}" style="background:${n.color};width:0%"></div></div>` +
      `<div class="heat-val" style="color:${n.color}">${n.pct}</div>` +
      `</div>`
    ).join("");

    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        el.querySelectorAll(".heat-fill").forEach((fill, i) => {
          setTimeout(() => { fill.style.width = fill.dataset.w + "%"; }, i*90);
        });
        io.unobserve(el);
      });
    }, {threshold:.3});
    io.observe(el);

    setInterval(() => {
      el.querySelectorAll(".heat-fill[data-w]").forEach(fill => {
        const base = parseInt(fill.dataset.w), d = ri(-2,3);
        fill.style.width = Math.max(55, Math.min(99, base+d)) + "%";
      });
    }, 5500);
  }

  /* ─── Activity feed ───────────────────────────────── */
  let _feedIdx = 0;
  function initActivityFeed() {
    const feed = $id("actFeed");
    if (!feed) return;
    const AV = window.Avatar;
    for (let i=0;i<7;i++) addFeedItem(ri(2,30));
    function addFeedItem(minAgo) {
      const m = genMember();
      const fn = pick(ACT_TEMPLATES);
      const msg = fn(m);
      const time = minAgo===0?"just now":`${minAgo}m ago`;
      const av = (AV && AV.img) ? AV.img(m.n, m.f, 30, "act-avatar", m.sb) : `<div class="act-dot"></div>`;
      const div = document.createElement("div");
      div.className = "act-item";
      div.innerHTML = `${av}<div class="act-text">${msg}</div><div class="act-time">${time}</div>`;
      div.style.opacity = "0"; div.style.transform = "translateY(-4px)";
      feed.insertBefore(div, feed.firstChild);
      requestAnimationFrame(() => { div.style.transition="opacity .35s,transform .35s"; div.style.opacity="1"; div.style.transform="none"; });
      while (feed.children.length > 10) feed.lastChild.remove();
    }
    // Faster: every 3.5-7s for a constantly-moving feed
    (function loop(){ addFeedItem(0); setText("feedOnline", ri(28,58)+" online"); setTimeout(loop, ri(3500, 7000)); })();
  }

  /* ─── Review scroll ───────────────────────────────── */
  function initReviews() {
    const wall = $id("reviewScroll");
    if (!wall) return;
    const AV = window.Avatar;
    const items = [...REVIEWS, ...REVIEWS];
    wall.innerHTML = items.map(r => {
      const av = (AV && AV.img)
        ? AV.img(r.name, r.flag, 28, "review-avatar-img", r.sb||0)
        : `<div class="review-avatar">${r.init}</div>`;
      return `<div class="review-item">` +
      `<div class="review-item-header">` +
        av +
        `<div><div class="review-name">${r.name} ${r.flag}</div></div>` +
        `<div class="review-stars">${"★".repeat(r.stars)}</div>` +
      `</div>` +
      `<div class="review-text">"${r.text}"</div>` +
      `</div>`;
    }).join("");
    // Auto-scroll
    let pos = 0;
    setInterval(() => {
      pos += 1;
      if (pos > wall.scrollHeight / 2) pos = 0;
      wall.scrollTop = pos;
    }, 40);
  }

  /* ─── Popup notifications ─────────────────────────── */
  function initPopups() {
    _popupWrap = document.createElement("div");
    _popupWrap.id = "sitePopups";
    document.body.appendChild(_popupWrap);
    function firePopup() {
      const m = genMember();
      const msg = pick(POPUP_TEMPLATES)(m);
      const AV = window.Avatar;
      const av = (AV && AV.img) ? AV.img(m.n, m.f, 30, "popup-avatar", m.sb) : `<div class="popup-flag">${m.f}</div>`;
      const card = document.createElement("div");
      card.className = "site-popup";
      card.innerHTML =
        av +
        `<div style="flex:1;min-width:0"><div class="popup-msg">${msg}</div><div class="popup-sub">just now · ${m.c}</div></div>` +
        `<div class="popup-dot"></div>`;
      _popupWrap.appendChild(card);
      requestAnimationFrame(() => card.classList.add("show"));
      setTimeout(() => {
        card.classList.remove("show");
        setTimeout(() => card.remove(), 380);
      }, 4600);
      while (_popupWrap.children.length > 3) _popupWrap.firstChild.remove();
    }
    (function schedule() { firePopup(); setTimeout(schedule, ri(9000,22000)); })(setTimeout(()=>{},ri(4000,7000)));
    setTimeout(() => { (function s(){firePopup();setTimeout(s,ri(9000,22000));})(); }, ri(4000,7000));
  }

  /* ─── Sound ─────────────────────────────────────────── */
  function toggleSound() {
    _soundOn = !_soundOn;
    const btn = $id("tickerSound");
    if (btn) btn.textContent = _soundOn ? "🔔" : "🔕";
    if (_soundOn && !_audioCtx) _audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    if (_soundOn && _audioCtx?.state === "suspended") _audioCtx.resume();
    playTone(_soundOn ? [660,880] : [440]);
  }
  function playTone(freqs) {
    if (!_soundOn || !_audioCtx) return;
    freqs.forEach((f,i) => {
      try {
        const o=_audioCtx.createOscillator(), g=_audioCtx.createGain();
        o.connect(g); g.connect(_audioCtx.destination);
        o.type="sine"; o.frequency.value=f;
        const t=_audioCtx.currentTime+i*.1;
        g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.06,t+.015);
        g.gain.exponentialRampToValueAtTime(.001,t+.22);
        o.start(t); o.stop(t+.25);
      } catch(_) {}
    });
  }

  /* ─── Scroll reveal ───────────────────────────────── */
  function initReveal() {
    if (!("IntersectionObserver" in window)) {
      document.querySelectorAll(".reveal").forEach(el => el.classList.add("visible"));
      return;
    }
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add("visible"); io.unobserve(e.target); }
      });
    }, {threshold:.07});
    document.querySelectorAll(".reveal").forEach(el => io.observe(el));
  }

  /* ─── Micro-interactions ──────────────────────────── */
  function initMicro() {
    // Ripple on all CTAs
    document.addEventListener("click", e => {
      const btn = e.target.closest(".btn-glow,.plan-btn");
      if (!btn) return;
      const r = document.createElement("span"); r.className = "ripple";
      const rect = btn.getBoundingClientRect();
      r.style.left = (e.clientX - rect.left - 10) + "px";
      r.style.top  = (e.clientY - rect.top  - 10) + "px";
      btn.style.position = "relative"; btn.style.overflow = "hidden";
      btn.appendChild(r);
      r.addEventListener("animationend", () => r.remove(), {once:true});
    }, {passive:true});

    // Plan card 3D tilt
    document.querySelectorAll(".plan-card").forEach(card => {
      card.addEventListener("mousemove", e => {
        const rect = card.getBoundingClientRect();
        const dx = (e.clientX - (rect.left + rect.width/2))  / (rect.width/2);
        const dy = (e.clientY - (rect.top  + rect.height/2)) / (rect.height/2);
        const base = card.classList.contains("plan-card-pro") ? "translateY(-10px) " : "";
        card.style.transform = `${base}perspective(800px) rotateX(${-dy*3.5}deg) rotateY(${dx*3.5}deg)`;
      });
      card.addEventListener("mouseleave", () => {
        const base = card.classList.contains("plan-card-pro") ? "translateY(-10px)" : "";
        card.style.transform = base;
      });
    });

    // Back to top
    const btt = $id("backToTop");
    if (btt) {
      window.addEventListener("scroll", () => btt.classList.toggle("visible", window.scrollY > 400), {passive:true});
      btt.addEventListener("click", () => window.scrollTo({top:0,behavior:"smooth"}));
    }

    // Navbar scroll
    const nb = $id("navbar");
    window.addEventListener("scroll", () => { if(nb) nb.classList.toggle("scrolled", window.scrollY > 30); }, {passive:true});
  }

  /* ─── FAQ accordion fix ───────────────────────────── */
  function initFAQ() {
    document.querySelectorAll(".faq-q").forEach(btn => {
      btn.addEventListener("click", () => {
        const item = btn.closest(".faq-item");
        const open = item.classList.toggle("open");
        btn.setAttribute("aria-expanded", String(open));
        const ans = item.querySelector(".faq-a");
        if (ans) ans.style.display = open ? "block" : "none";
        const arrow = btn.querySelector(".faq-arrow");
        if (arrow) arrow.textContent = open ? "−" : "+";
      });
    });
  }


  /* ─── Winner card live timestamps ─────────────────── */
  function initWinnerTimes() {
    const times = document.querySelectorAll(".winners-grid .tg-time");
    if (!times.length) return;
    // Seed each card with a base "minutes ago"
    const bases = [2, 8, 15, 22];
    times.forEach((el, i) => { el.dataset.min = bases[i % bases.length]; });
    function refresh() {
      times.forEach(el => {
        let m = parseInt(el.dataset.min) || 2;
        // Occasionally reset a card to "just now" to simulate a fresh detection
        if (Math.random() < 0.12) m = 0;
        else m += 1;
        el.dataset.min = m;
        el.textContent = m === 0 ? "just now" : m + " min ago";
      });
    }
    setInterval(refresh, ri(8000, 14000));
  }

  /* ─── Init ────────────────────────────────────────── */
  function init() {
    initCanvas();
    initTicker();
    initCounters();
    initTerminal();
    initNicheHeat();
    initActivityFeed();
    initReviews();
    initWinnerTimes();
    initPopups();
    initReveal();
    initMicro();
    initFAQ();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();
