/**
 * eBay Titan AI — Firebase Configuration & Auth Module
 * =====================================================
 * Version: 2.1 — Production-stable
 *
 * HOW ENVIRONMENT VARIABLES WORK:
 * ================================
 * The placeholder strings below are replaced at Netlify build time by build.sh.
 * build.sh reads environment variables from Netlify's secure vault and uses
 * perl/sed to inject them directly into this file before deployment.
 *
 * REQUIRED ENV VARS (Netlify Dashboard → Site → Environment Variables):
 *   VITE_FIREBASE_API_KEY
 *   VITE_FIREBASE_AUTH_DOMAIN
 *   VITE_FIREBASE_PROJECT_ID
 *   VITE_FIREBASE_STORAGE_BUCKET
 *   VITE_FIREBASE_MESSAGING_SENDER_ID
 *   VITE_FIREBASE_APP_ID
 *
 * LOCAL DEV: Replace the strings below directly with your Firebase values.
 * Get them from: Firebase Console → Project Settings → Your Apps → Web App
 */

"use strict";

// ─────────────────────────────────────────────────────────────
// FIREBASE CONFIG — injected by build.sh at deploy time
// ─────────────────────────────────────────────────────────────
const FIREBASE_CONFIG = {
  apiKey:            "REPLACE_WITH_YOUR_API_KEY",
  authDomain:        "REPLACE_WITH_YOUR_PROJECT_ID.firebaseapp.com",
  projectId:         "REPLACE_WITH_YOUR_PROJECT_ID",
  storageBucket:     "REPLACE_WITH_YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "REPLACE_WITH_YOUR_SENDER_ID",
  appId:             "REPLACE_WITH_YOUR_APP_ID"
};

// Admin email — enforced client-side AND in Firestore security rules
const ADMIN_EMAIL = "loordmri428@gmail.com";

// ─────────────────────────────────────────────────────────────
// VALIDATION — detect if build injection failed
// ─────────────────────────────────────────────────────────────
(function validateConfig() {
  if (FIREBASE_CONFIG.apiKey.includes("REPLACE_WITH")) {
    const msg = [
      "eBay Titan AI: Firebase configuration is not set.",
      "",
      "If you are deploying to Netlify:",
      "  1. Go to Netlify Dashboard → Site → Environment Variables",
      "  2. Add: VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN,",
      "          VITE_FIREBASE_PROJECT_ID, VITE_FIREBASE_STORAGE_BUCKET,",
      "          VITE_FIREBASE_MESSAGING_SENDER_ID, VITE_FIREBASE_APP_ID",
      "  3. Trigger a new deploy",
      "",
      "If you are running locally:",
      "  Open firebase-config.js and replace the REPLACE_WITH_... strings",
      "  with your actual Firebase project values.",
    ].join("\n");
    console.error(msg);
    // Show user-friendly error on auth pages
    document.addEventListener("DOMContentLoaded", () => {
      const errorBanners = document.querySelectorAll(".auth-error, #authError");
      errorBanners.forEach(el => {
        el.innerHTML = "⚙️ Platform configuration incomplete. Please contact support at <a href='mailto:ebaysupporthunter@gmail.com' style='color:var(--neon)'>ebaysupporthunter@gmail.com</a>";
        el.classList.add("show");
        el.style.display = "block";
      });
    });
  }
})();

// ─────────────────────────────────────────────────────────────
// FIREBASE INITIALIZATION
// ─────────────────────────────────────────────────────────────
let _auth = null;
let _db   = null;
let _initPromise = null;
let _initialized = false;

/**
 * Initialize Firebase — idempotent, safe to call multiple times.
 * Returns { auth, db } synchronously once initialized.
 */
function getFirebase() {
  if (_initialized && _auth && _db) return { auth: _auth, db: _db };

  if (!window.firebase) {
    throw new Error(
      "Firebase SDK not loaded. Check that the Firebase CDN scripts appear " +
      "before firebase-config.js in the HTML <head>."
    );
  }

  // Initialize app only once across the page
  let app;
  if (!firebase.apps.length) {
    app = firebase.initializeApp(FIREBASE_CONFIG);
  } else {
    app = firebase.app();
  }

  _auth = firebase.auth();
  _db   = firebase.firestore();

  // Set LOCAL persistence (survives page refresh, cleared on signOut)
  // This is a fire-and-forget — not awaited intentionally in compat mode
  _auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(err => {
    console.warn("Firebase: could not set persistence:", err.code);
  });

  // Firestore settings — enable offline support
  _db.settings({
    cacheSizeBytes: firebase.firestore.CACHE_SIZE_UNLIMITED
  });

  _initialized = true;
  return { auth: _auth, db: _db };
}

/**
 * Returns a promise that resolves when Firebase is ready.
 * Useful in cases where you need to await initialization.
 */
function waitForFirebase() {
  return new Promise((resolve, reject) => {
    try {
      resolve(getFirebase());
    } catch (err) {
      reject(err);
    }
  });
}

// ─────────────────────────────────────────────────────────────
// AUTH MODULE
// ─────────────────────────────────────────────────────────────
const titanAuth = {

  // ── Register new user ──
  async register({ firstName, lastName, email, password }) {
    const { auth, db } = getFirebase();

    let cred;
    try {
      cred = await auth.createUserWithEmailAndPassword(email.trim().toLowerCase(), password);
    } catch (err) {
      throw new Error(titanAuth._mapError(err.code));
    }

    const user = cred.user;

    // Set display name
    await user.updateProfile({
      displayName: `${firstName} ${lastName || ""}`.trim()
    }).catch(() => {}); // non-critical

    // Create Firestore user document
    // Wrapped in try — if Firestore write fails we still have the auth account
    try {
      await db.collection("users").doc(user.uid).set({
        uid:          user.uid,
        firstName:    firstName.trim(),
        lastName:     (lastName || "").trim(),
        email:        email.trim().toLowerCase(),
        role:         "user",
        hasAccess:    false,
        emailVerified:false,
        progress:     [],
        lastActivity: null,
        createdAt:    firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt:    firebase.firestore.FieldValue.serverTimestamp(),
        loginCount:   0,
        lastLogin:    null,
        paypalOrderId:null,
        purchasedAt:  null,
        plan:         "free",
        scansToday:   0,
        scanDate:     null,
        totalScans:   0,
        workspace:    "",
        avatarId:     "",
        theme:        "titan-dark",
        onboarded:    false,
      });
    } catch (firestoreErr) {
      // Firestore write failed — delete the auth account to avoid orphaned accounts
      await user.delete().catch(() => {});
      throw new Error(
        "Account creation failed (database error). Please try again or contact support."
      );
    }

    // Send verification email
    try {
      await user.sendEmailVerification({
        url: `${window.location.origin}/login.html?verified=1`
      });
    } catch (emailErr) {
      console.warn("Verification email failed:", emailErr.code);
      // Don't throw — account was created, just warn
    }

    // Sign out until email is verified
    await auth.signOut();

    return { ok: true, email: user.email };
  },

  // ── Login ──
  async login({ email, password }) {
    const { auth, db } = getFirebase();

    let cred;
    try {
      cred = await auth.signInWithEmailAndPassword(email.trim().toLowerCase(), password);
    } catch (err) {
      throw new Error(titanAuth._mapError(err.code));
    }

    const user = cred.user;

    // Reload to get latest emailVerified from server
    await user.reload().catch(() => {});

    if (!user.emailVerified) {
      await auth.signOut();
      const err = new Error(
        "Please verify your email before signing in. Check your inbox for the verification link."
      );
      err.cause = "unverified";
      throw err;
    }

    // Read Firestore user document
    let userData;
    try {
      const snap = await db.collection("users").doc(user.uid).get();
      if (!snap.exists) {
        // Document missing — this can happen if Firestore write failed during register
        // Create it now
        userData = {
          uid:       user.uid,
          email:     user.email,
          role:      "user",
          hasAccess: false,
        };
        await db.collection("users").doc(user.uid).set({
          ...userData,
          emailVerified: true,
          createdAt: firebase.firestore.FieldValue.serverTimestamp(),
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
        });
      } else {
        userData = snap.data();
      }
    } catch (firestoreErr) {
      console.error("Firestore read error during login:", firestoreErr.code);
      // If Firestore is unavailable, check if it's the admin
      if (user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        userData = { role: "admin", hasAccess: true };
      } else {
        await auth.signOut();
        throw new Error("Could not verify account. Please try again.");
      }
    }

    const isAdmin = user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()
                    || userData.role === "admin";

    if (!isAdmin && !userData.hasAccess) {
      await auth.signOut();
      const err = new Error(
        "You don't have platform access. Please complete your purchase to continue."
      );
      err.cause = "no_access";
      throw err;
    }

    // Update login stats (non-blocking)
    db.collection("users").doc(user.uid).update({
      lastLogin:    firebase.firestore.FieldValue.serverTimestamp(),
      loginCount:   firebase.firestore.FieldValue.increment(1),
      emailVerified:true,
      updatedAt:    firebase.firestore.FieldValue.serverTimestamp(),
    }).catch(() => {});

    return {
      ok:        true,
      uid:       user.uid,
      email:     user.email,
      name:      user.displayName || userData.firstName || "",
      firstName: userData.firstName || "",
      role:      isAdmin ? "admin" : (userData.role || "user"),
      hasAccess: true,
    };
  },

  // ── Logout ──
  async logout() {
    try {
      const { auth } = getFirebase();
      await auth.signOut();
    } catch (_) {}
    // Clear local storage keys
    try { localStorage.removeItem("titan_role"); } catch(_) {}
    try { sessionStorage.removeItem("titan_last_panel"); } catch(_) {}
    return { ok: true };
  },

  // ── Password reset ──
  async sendPasswordReset(email) {
    try {
      const { auth } = getFirebase();
      await auth.sendPasswordResetEmail(email.trim().toLowerCase(), {
        url: `${window.location.origin}/login.html?reset=1`
      });
    } catch (err) {
      // Silently succeed — never reveal if email exists
      if (err.code === "auth/network-request-failed") {
        throw new Error("Network error. Check your connection and try again.");
      }
    }
    return { ok: true };
  },

  // ── Resend verification email ──
  async resendVerification() {
    const { auth } = getFirebase();
    const user = auth.currentUser;
    if (!user) throw new Error("No user signed in.");
    await user.sendEmailVerification({
      url: `${window.location.origin}/login.html?verified=1`
    });
    return { ok: true };
  },

  // ── Subscribe to auth state changes ──
  onAuthChange(callback) {
    try {
      const { auth } = getFirebase();
      return auth.onAuthStateChanged(callback);
    } catch(err) {
      callback(null);
      return () => {};
    }
  },

  // ── Route guard: require authenticated + verified + paid user ──
  requireAuth() {
    return new Promise((resolve, reject) => {
      let resolved = false;

      // Timeout — if Firebase doesn't respond in 8 seconds, redirect to login
      const timeout = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          window.location.replace("/login.html?reason=timeout");
          reject(new Error("auth_timeout"));
        }
      }, 8000);

      try {
        const { auth, db } = getFirebase();
        const unsubscribe = auth.onAuthStateChanged(async (user) => {
          if (resolved) return;
          unsubscribe();
          clearTimeout(timeout);
          resolved = true;

          if (!user) {
            const dest = encodeURIComponent(
              window.location.pathname + window.location.search
            );
            window.location.replace(`/login.html?redirect=${dest}&reason=auth_required`);
            return reject(new Error("not_authenticated"));
          }

          // Reload for fresh emailVerified
          await user.reload().catch(() => {});

          if (!user.emailVerified) {
            await auth.signOut().catch(() => {});
            window.location.replace("/login.html?reason=unverified");
            return reject(new Error("unverified"));
          }

          // Read Firestore doc
          let userData = { role: "user", hasAccess: false };
          try {
            const snap = await db.collection("users").doc(user.uid).get();
            if (snap.exists) userData = snap.data();
          } catch (firestoreErr) {
            console.warn("requireAuth: Firestore read failed:", firestoreErr.code);
            // Allow admin through even if Firestore is unavailable
            if (user.email.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
              window.location.replace("/login.html?reason=error");
              return reject(firestoreErr);
            }
          }

          const adminFlag = user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()
                            || userData.role === "admin";

          if (!adminFlag && !userData.hasAccess) {
            await auth.signOut().catch(() => {});
            window.location.replace("/login.html?reason=no_access");
            return reject(new Error("no_access"));
          }

          resolve({
            uid:       user.uid,
            email:     user.email,
            name:      user.displayName || userData.firstName || "",
            firstName: userData.firstName || "",
            role:      adminFlag ? "admin" : (userData.role || "user"),
            hasAccess: true,
          });
        });
      } catch (err) {
        clearTimeout(timeout);
        window.location.replace("/login.html?reason=error");
        reject(err);
      }
    });
  },

  // ── Route guard: admin only ──
  requireAdmin() {
    return new Promise((resolve, reject) => {
      titanAuth.requireAuth().then(userData => {
        if (userData.role !== "admin") {
          window.location.replace("/dashboard.html");
          return reject(new Error("not_admin"));
        }
        resolve(userData);
      }).catch(reject);
    });
  },

  // ── Get Firestore user doc ──
  async getUserDoc(uid) {
    try {
      const { db } = getFirebase();
      const snap = await db.collection("users").doc(uid).get();
      return snap.exists ? snap.data() : null;
    } catch (_) { return null; }
  },

  // ── Update Firestore user doc ──
  async updateUserDoc(uid, updates) {
    const { db } = getFirebase();
    await db.collection("users").doc(uid).update({
      ...updates,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { ok: true };
  },

  // ── Admin: list all users ──
  async listUsers(limitN = 200) {
    const { db } = getFirebase();
    const snap = await db.collection("users")
      .orderBy("createdAt", "desc")
      .limit(limitN)
      .get();
    return snap.docs.map(d => d.data());
  },

  // ── Admin: set hasAccess ──
  async adminSetAccess(uid, hasAccess) {
    const { db } = getFirebase();
    await db.collection("users").doc(uid).update({
      hasAccess,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { ok: true };
  },

  // ── Admin: set role ──
  async adminSetRole(uid, role) {
    const { db } = getFirebase();
    await db.collection("users").doc(uid).update({
      role,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { ok: true };
  },

  // ── Admin: get platform stats ──
  async getStats() {
    const { db } = getFirebase();
    try {
      const [allSnap, accessSnap] = await Promise.all([
        db.collection("users").get(),
        db.collection("users").where("hasAccess", "==", true).get(),
      ]);
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      let newThisWeek = 0;
      allSnap.docs.forEach(d => {
        const data = d.data();
        if (data.createdAt?.toDate && data.createdAt.toDate() > weekAgo) {
          newThisWeek++;
        }
      });
      return {
        totalUsers:  allSnap.size,
        withAccess:  accessSnap.size,
        newThisWeek,
      };
    } catch (_) {
      return { totalUsers: 0, withAccess: 0, newThisWeek: 0 };
    }
  },

  // ──────────────────────────────────────────────────────────
  // ACCOUNT-BASED SCANNER USAGE (Phase 2 + Phase 9)
  // Daily scan limit lives in Firestore, keyed to the user — so it
  // survives cookie/history/browser clearing.
  // ──────────────────────────────────────────────────────────
  _todayStr() {
    const d = new Date();
    return d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
  },

  async getScanUsage(uid) {
    const FREE_LIMIT = 3;
    try {
      const { db } = getFirebase();
      const snap = await db.collection("users").doc(uid).get();
      if (!snap.exists) return { used:0, limit:FREE_LIMIT, remaining:FREE_LIMIT, plan:"free" };
      const data = snap.data();
      const plan = data.plan || (data.hasAccess ? "pro" : "free");
      if (plan === "pro" || plan === "premium" || data.role === "admin") {
        return { used:data.scansToday||0, limit:Infinity, remaining:Infinity, plan };
      }
      const today = titanAuth._todayStr();
      const used = (data.scanDate === today) ? (data.scansToday||0) : 0;
      return { used, limit:FREE_LIMIT, remaining:Math.max(0,FREE_LIMIT-used), plan:"free" };
    } catch (e) {
      return { used:0, limit:FREE_LIMIT, remaining:FREE_LIMIT, plan:"free", error:true };
    }
  },

  async recordScan(uid) {
    const FREE_LIMIT = 3;
    const { db } = getFirebase();
    const today = titanAuth._todayStr();
    const ref = db.collection("users").doc(uid);
    try {
      const snap = await ref.get();
      const data = snap.exists ? snap.data() : {};
      const sameDay = data.scanDate === today;
      const newCount = sameDay ? (data.scansToday||0)+1 : 1;
      await ref.update({
        scansToday:   newCount,
        scanDate:     today,
        totalScans:   firebase.firestore.FieldValue.increment(1),
        lastActivity: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt:    firebase.firestore.FieldValue.serverTimestamp(),
      });
      const plan = data.plan || (data.hasAccess ? "pro" : "free");
      const limit = (plan === "free") ? FREE_LIMIT : Infinity;
      return { used:newCount, limit, remaining:Math.max(0,limit-newCount), plan };
    } catch (e) { return { error:true }; }
  },

  async saveProfile(uid, { workspace, avatarId, theme, onboarded }) {
    const { db } = getFirebase();
    const updates = { updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
    if (workspace !== undefined) updates.workspace = String(workspace).slice(0,40);
    if (avatarId  !== undefined) updates.avatarId  = String(avatarId).slice(0,40);
    if (theme     !== undefined) updates.theme     = String(theme).slice(0,20);
    if (onboarded !== undefined) updates.onboarded = !!onboarded;
    await db.collection("users").doc(uid).update(updates);
    return { ok:true };
  },

  // ── Map Firebase error codes → user-friendly messages ──
  _mapError(code) {
    const map = {
      "auth/user-not-found":        "No account found with that email address.",
      "auth/wrong-password":        "Incorrect password. Please try again.",
      "auth/invalid-credential":    "Invalid email or password.",
      "auth/invalid-email":         "Please enter a valid email address.",
      "auth/user-disabled":         "This account has been disabled. Contact support.",
      "auth/too-many-requests":     "Too many failed attempts. Please wait a few minutes and try again.",
      "auth/email-already-in-use":  "An account with this email already exists. Please sign in.",
      "auth/weak-password":         "Password must be at least 6 characters.",
      "auth/network-request-failed":"Network error. Check your connection and try again.",
      "auth/popup-closed-by-user":  "Sign-in was cancelled. Please try again.",
      "auth/requires-recent-login": "Please sign in again to complete this action.",
      "auth/operation-not-allowed": "Email/password sign-in is not enabled. Contact support.",
    };
    return map[code] || `Authentication error (${code}). Please try again.`;
  },
};

// ─────────────────────────────────────────────────────────────
// GLOBAL EXPORTS
// ─────────────────────────────────────────────────────────────
window.titanAuth   = titanAuth;
window.ADMIN_EMAIL = ADMIN_EMAIL;
window.getFirebase = getFirebase;
window.waitForFirebase = waitForFirebase;
