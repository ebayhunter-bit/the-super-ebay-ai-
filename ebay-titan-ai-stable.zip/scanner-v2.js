/**
 * eBay Titan AI — scanner-v2.js
 * ===============================
 * Conversion-focused interactive scanner.
 *  - 3 free scans/day (localStorage, date-keyed)
 *  - 5-step AI processing sequence (4-6s)
 *  - Free results: Demand Score, Demand Trend, VERO Safety, Opportunity Rating
 *  - Locked premium: 9 blurred metrics behind upgrade gate
 *  - Upgrade modal after each scan; hard limit modal after 3rd
 */
"use strict";
(function(){
  function $(id){ return document.getElementById(id); }

  /* ── Daily scan limit ──
     Account-based when signed in (Firestore, survives storage clearing).
     Falls back to localStorage for anonymous visitors on the public page. */
  var LIMIT = 3;
  var _account = null;       // { uid } when signed in
  var _usage   = { used:0, limit:LIMIT, remaining:LIMIT, plan:"free" };
  var _memScans = 0;

  function todayKey(){ var d=new Date(); return "titan_scans_"+d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); }
  function lsGetScans(){ try { return parseInt(localStorage.getItem(todayKey())||"0",10)||0; } catch(e){ return _memScans; } }
  function lsIncScans(){ try { var n=lsGetScans()+1; localStorage.setItem(todayKey(),String(n)); return n; } catch(e){ return ++_memScans; } }

  // Sync usage from the signed-in account (called on auth state change)
  function refreshAccountUsage(cb){
    if(!_account || !window.titanAuth || !window.titanAuth.getScanUsage){ if(cb)cb(); return; }
    window.titanAuth.getScanUsage(_account.uid).then(function(u){
      if(u && !u.error){ _usage = u; updateQuotaDisplay(); }
      if(cb)cb();
    }).catch(function(){ if(cb)cb(); });
  }

  // Unified read: returns scans used today
  function getScans(){ return _account ? (_usage.used||0) : lsGetScans(); }
  // Unified read: is the user unlimited (paid/admin)?
  function isUnlimited(){ return _account && (_usage.limit===Infinity || _usage.plan==="pro" || _usage.plan==="premium"); }
  // Unified write: records one scan, returns new count. Account write is async (fire-and-forget + local mirror).
  function incScans(){
    if(_account){
      _usage.used = (_usage.used||0) + 1;
      if(window.titanAuth && window.titanAuth.recordScan){
        window.titanAuth.recordScan(_account.uid).then(function(u){ if(u && !u.error){ _usage=u; updateQuotaDisplay(); } });
      }
      return _usage.used;
    }
    return lsIncScans();
  }

  function updateQuotaDisplay(){
    var q=$("sv2Quota"); if(!q)return;
    if(isUnlimited()){ q.textContent="Unlimited scans · "+( _usage.plan==="premium"?"Premium":"Pro"); q.classList.remove("sv2-quota-low"); return; }
    var left=Math.max(0, LIMIT - getScans());
    q.textContent = left>0 ? left+" free scan"+(left===1?"":"s")+" today" : "Daily limit reached";
    q.classList.toggle("sv2-quota-low", left===0);
  }

  // Auth state (Phase 13 — scanner is account-gated)
  var _authReady = false;   // has the first auth callback fired?
  function isAuthed(){ return !!_account; }

  // Detect signed-in user. Scanner now REQUIRES auth before scanning.
  function initAccount(){
    if(window.titanAuth && window.titanAuth.onAuthChange){
      try {
        window.titanAuth.onAuthChange(function(user){
          _authReady = true;
          if(user && user.uid){ _account={uid:user.uid}; refreshAccountUsage(); }
          else { _account=null; updateQuotaDisplay(); }
          reflectAuthInButton();
        });
      } catch(e){ _authReady = true; }
    } else {
      // No auth module present — treat as not-authed (gate stays on)
      _authReady = true;
    }
  }

  // Reflect auth state in the scanner button label so the CTA is honest
  function reflectAuthInButton(){
    var btnTxt=$("sv2BtnText"), q=$("sv2Quota");
    if(!btnTxt) return;
    if(isAuthed()){
      btnTxt.textContent="⚡ Run AI Scan";
    } else {
      btnTxt.textContent="🔓 Sign in to Scan";
      if(q){ q.textContent="Create a free account for 3 daily scans"; }
    }
  }

  function showAuthModal(){
    var m=$("sv2AuthModal");
    if(m){ m.style.display="flex"; requestAnimationFrame(function(){ m.classList.add("show"); }); }
  }

  /* ── Deterministic metric generation from keyword ── */
  function seedFrom(s){ var h=0; s=(s||"product").toLowerCase(); for(var i=0;i<s.length;i++){h=(Math.imul(31,h)+s.charCodeAt(i))|0;} return Math.abs(h)>>>0; }
  function rangeFrom(seed, off, min, max){ return min + (Math.abs((seed*2654435761+off*40503)|0) % (max-min+1)); }

  function buildIntel(kw){
    if(!kw || typeof kw!=="string") kw="product";
    kw = kw.trim().toLowerCase() || "product";
    var s = seedFrom(kw);
    var demand   = rangeFrom(s, 1, 74, 96);
    var veroSafe = rangeFrom(s, 2, 0, 100) > 22;       // ~78% safe
    var trendPct = rangeFrom(s, 3, 8, 55);
    var comp     = rangeFrom(s, 4, 24, 68);
    var aiConf   = rangeFrom(s, 5, 78, 96);
    var sat      = rangeFrom(s, 6, 31, 72);
    var supplier = rangeFrom(s, 7, 28, 80);
    var profit   = rangeFrom(s, 8, 6, 24);             // $ per unit
    var revenue  = rangeFrom(s, 9, 4, 38) * 100;       // monthly $
    var price    = (rangeFrom(s, 10, 899, 2999)/100).toFixed(2);
    var trendDir = trendPct > 28 ? "Rising" : trendPct > 16 ? "Stable" : "Cooling";
    var opp      = demand>=88 ? "Very High" : demand>=80 ? "High" : demand>=74 ? "Moderate" : "Fair";
    var oppCol   = demand>=88 ? "#10b981" : demand>=80 ? "#a78bfa" : demand>=74 ? "#f59e0b" : "#60a5fa";
    return { kw, demand, veroSafe, trendPct, trendDir, comp, aiConf, sat, supplier,
             profit, revenue, price, opp, oppCol };
  }

  /* ── 5-step AI sequence ── */
  var STEPS = [
    { t:"Connecting to Titan AI Engine...",   d:"🔌 Establishing secure session" },
    { t:"Analyzing demand signals...",         d:"📊 Sales velocity · watch counts · sell-through" },
    { t:"Checking VERO risk...",               d:"🛡️ Cross-referencing 450+ protected brands" },
    { t:"Scanning market competition...",      d:"🔬 Active sellers · price spread · saturation" },
    { t:"Generating intelligence report...",   d:"🧠 Correlating multi-signal AI score" },
  ];

  var busy = false;

  function runScan(kw){
    if(busy) return;

    // ── Phase 13: Account gate — anonymous visitors cannot scan ──
    // If auth hasn't reported yet, wait a beat then re-check (avoids false gate on slow Firebase).
    if(!isAuthed()){
      if(!_authReady){ setTimeout(function(){ runScan(kw); }, 600); return; }
      showAuthModal();
      return;
    }

    kw = (kw || $("sv2Input").value || "").trim();
    if(!kw){ $("sv2Input").focus(); return; }

    // Check daily limit (paid/admin = unlimited)
    if(!isUnlimited() && getScans() >= LIMIT){ showLimitModal(); return; }

    busy = true;
    var btn=$("sv2Btn"), btnTxt=$("sv2BtnText");
    btn.disabled=true; btnTxt.textContent="Scanning...";
    $("sv2Results").style.display="none";
    var proc=$("sv2Process"); proc.style.display="block";
    var stepsEl=$("sv2Steps"); stepsEl.innerHTML="";
    var fill=$("sv2ProgFill"); fill.style.width="0%";

    // Render step rows
    STEPS.forEach(function(st,i){
      var row=document.createElement("div");
      row.className="sv2-step"; row.id="sv2step"+i;
      row.innerHTML='<span class="sv2-step-spin"></span><div class="sv2-step-body"><div class="sv2-step-t">'+st.t+'</div><div class="sv2-step-d">'+st.d+'</div></div><span class="sv2-step-check">✓</span>';
      stepsEl.appendChild(row);
    });

    // Total 4-6s split across 5 steps
    var total = 4200 + Math.floor(Math.random()*1600);
    var per = total / STEPS.length;
    var i=0;
    function nextStep(){
      if(i>0){ var prev=$("sv2step"+(i-1)); if(prev) prev.classList.add("done"); }
      if(i<STEPS.length){
        var cur=$("sv2step"+i); if(cur) cur.classList.add("active");
        fill.style.width = Math.round(((i+1)/STEPS.length)*100)+"%";
        i++;
        setTimeout(nextStep, per);
      } else {
        setTimeout(function(){ proc.style.display="none"; showResults(kw); }, 300);
      }
    }
    nextStep();
  }

  function showResults(kw){
    var d = buildIntel(kw);
    var n = incScans();

    $("sv2ResultKw").textContent = kw.replace(/\b\w/g, function(c){return c.toUpperCase();});
    $("sv2Results").style.display="block";

    // Free metrics (4)
    var FREE = [
      { lbl:"Demand Score",     val:d.demand,            col:"#a78bfa", bar:d.demand },
      { lbl:"Demand Trend",     val:d.trendDir,          col:d.trendDir==="Rising"?"#10b981":d.trendDir==="Stable"?"#f59e0b":"#60a5fa", bar:d.trendPct+30 },
      { lbl:"VERO Safety",      val:d.veroSafe?"Safe":"Caution", col:d.veroSafe?"#10b981":"#f59e0b", bar:d.veroSafe?94:48 },
      { lbl:"Opportunity",      val:d.opp,               col:d.oppCol, bar:d.demand },
    ];
    $("sv2FreeGrid").innerHTML = FREE.map(function(m){
      return '<div class="sv2-free-card"><div class="sv2-fc-lbl">'+m.lbl+'</div>'+
             '<div class="sv2-fc-val" style="color:'+m.col+'">'+m.val+'</div>'+
             '<div class="sv2-fc-bar-track"><div class="sv2-fc-bar" style="background:'+m.col+';width:0%" data-w="'+Math.min(100,m.bar)+'"></div></div></div>';
    }).join("");
    // Animate bars
    setTimeout(function(){
      var bars=$("sv2FreeGrid").querySelectorAll(".sv2-fc-bar");
      bars.forEach(function(b,idx){ setTimeout(function(){ b.style.width=b.dataset.w+"%"; }, idx*90); });
    }, 60);

    // Locked metrics (9) — show blurred teaser values
    var LOCKED = [
      { lbl:"Profit Analysis",        teaser:"$"+d.profit+"/unit" },
      { lbl:"Competition Intelligence", teaser:d.comp+"%" },
      { lbl:"Supplier Difficulty",    teaser:d.supplier+"%" },
      { lbl:"Market Saturation",      teaser:d.sat+"%" },
      { lbl:"AI Confidence Score",    teaser:d.aiConf+"%" },
      { lbl:"Trend Forecast",         teaser:"+"+d.trendPct+"%" },
      { lbl:"Recommended Price",      teaser:"$"+d.price },
      { lbl:"Est. Monthly Revenue",   teaser:"$"+d.revenue.toLocaleString() },
      { lbl:"Full Intelligence Report", teaser:"PDF" },
    ];
    $("sv2LockedGrid").innerHTML = LOCKED.map(function(m){
      return '<div class="sv2-locked-card" data-upgrade="1"><div class="sv2-lc-lbl">'+m.lbl+'</div>'+
             '<div class="sv2-lc-val">'+m.teaser+'</div><div class="sv2-lc-lock">🔒</div></div>';
    }).join("");

    busy=false;
    var btn=$("sv2Btn"); btn.disabled=false; $("sv2BtnText").textContent="⚡ Run AI Scan";

    // Update quota display
    var left = Math.max(0, LIMIT - n);
    $("sv2Quota").textContent = left>0 ? left+" free scan"+(left===1?"":"s")+" left today" : "Daily limit reached";
    $("sv2Quota").classList.toggle("sv2-quota-low", left===0);

    // After EACH scan, show upgrade modal (slight delay so user sees results first)
    if(!isUnlimited() && n >= LIMIT){
      setTimeout(showLimitModal, 1400);
    } else {
      setTimeout(showUpgradeModal, 1600);
    }
  }

  /* ── Modals ── */
  function showUpgradeModal(){ var m=$("sv2Modal"); if(m){ m.style.display="flex"; requestAnimationFrame(function(){m.classList.add("show");}); } }
  function showLimitModal(){ var m=$("sv2LimitModal"); if(m){ m.style.display="flex"; requestAnimationFrame(function(){m.classList.add("show");}); } }
  function closeModal(m){ if(!m)return; m.classList.remove("show"); setTimeout(function(){ m.style.display="none"; }, 280); }

  /* ── Wire up ── */
  function init(){
    var btn=$("sv2Btn"), input=$("sv2Input");
    if(!btn||!input) return;

    btn.addEventListener("click", function(){ runScan(input.value); });
    input.addEventListener("keydown", function(e){ if(e.key==="Enter") runScan(input.value); });

    document.querySelectorAll(".sv2-chip[data-kw]").forEach(function(c){
      c.addEventListener("click", function(){ input.value=c.dataset.kw; runScan(c.dataset.kw); });
    });

    // Locked card click → upgrade modal
    document.addEventListener("click", function(e){
      var lc=e.target.closest(".sv2-locked-card,[data-upgrade]");
      if(lc){ showUpgradeModal(); }
      var ub=e.target.closest("#sv2UnlockBtn");
      if(ub){ showUpgradeModal(); }
    });

    // Modal close buttons + overlay click
    var mClose=$("sv2ModalClose"), lClose=$("sv2LimitClose"), aClose=$("sv2AuthClose");
    if(mClose) mClose.addEventListener("click", function(){ closeModal($("sv2Modal")); });
    if(lClose) lClose.addEventListener("click", function(){ closeModal($("sv2LimitModal")); });
    if(aClose) aClose.addEventListener("click", function(){ closeModal($("sv2AuthModal")); });
    [$("sv2Modal"),$("sv2LimitModal"),$("sv2AuthModal")].forEach(function(ov){
      if(ov) ov.addEventListener("click", function(e){ if(e.target===ov) closeModal(ov); });
    });
    // "View Plans" links also close modal so the #pricing anchor scroll works
    ["sv2ModalPlans","sv2LimitPlans"].forEach(function(id){
      var el=$(id); if(el) el.addEventListener("click", function(){ closeModal($("sv2Modal")); closeModal($("sv2LimitModal")); });
    });
    document.addEventListener("keydown", function(e){ if(e.key==="Escape"){ closeModal($("sv2Modal")); closeModal($("sv2LimitModal")); closeModal($("sv2AuthModal")); } });

    // Initialize quota display + detect signed-in account
    updateQuotaDisplay();
    initAccount();
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
