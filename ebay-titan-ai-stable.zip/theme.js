/**
 * eBay Titan AI — theme.js
 * Minimal theme switcher. Default = Titan Dark.
 * Persists to localStorage immediately; syncs to Firebase profile when signed in.
 * Visual only — never touches scanner/auth/layout logic.
 */
"use strict";
(function(){
  var THEMES = [
    { id:"titan-dark",     label:"Titan Dark",     sw:"tsw-dark" },
    { id:"command-center", label:"Command Center", sw:"tsw-command" },
    { id:"aurora",         label:"Aurora",         sw:"tsw-aurora" },
    { id:"titanium",       label:"Titanium",       sw:"tsw-titanium" },
  ];
  var KEY = "titan_theme";

  function apply(id){
    if(id && id !== "titan-dark") document.documentElement.setAttribute("data-theme", id);
    else document.documentElement.removeAttribute("data-theme");
  }
  function saved(){ try { return localStorage.getItem(KEY) || "titan-dark"; } catch(e){ return "titan-dark"; } }
  function store(id){ try { localStorage.setItem(KEY, id); } catch(e){} }

  // Apply saved theme ASAP (before paint where possible)
  apply(saved());

  function syncToProfile(id){
    if(window.titanAuth && window.titanAuth.onAuthChange && window.titanAuth.saveProfile){
      try {
        window.titanAuth.onAuthChange(function(u){
          if(u && u.uid){ window.titanAuth.saveProfile(u.uid, { theme:id }).catch(function(){}); }
        });
      } catch(e){}
    }
  }

  function buildSwitcher(){
    var host = document.getElementById("themeSwitcher");
    if(!host) return;
    var cur = saved();
    host.innerHTML =
      '<button class="theme-btn" id="themeBtn" aria-haspopup="true" aria-expanded="false">'
      + '🎨 <span class="theme-btn-label">Theme</span></button>'
      + '<div class="theme-menu" id="themeMenu" role="menu">'
      + THEMES.map(function(t){
          return '<button class="theme-opt'+(t.id===cur?" active":"")+'" data-theme-id="'+t.id+'" role="menuitem">'
               + '<span class="theme-swatch '+t.sw+'"></span>'+t.label+'</button>';
        }).join("")
      + '</div>';

    var btn=document.getElementById("themeBtn"), menu=document.getElementById("themeMenu");
    btn.addEventListener("click", function(e){
      e.stopPropagation();
      var open=menu.classList.toggle("open");
      btn.setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("click", function(){ menu.classList.remove("open"); btn.setAttribute("aria-expanded","false"); });
    menu.addEventListener("click", function(e){
      var opt=e.target.closest(".theme-opt"); if(!opt) return;
      var id=opt.getAttribute("data-theme-id");
      apply(id); store(id); syncToProfile(id);
      menu.querySelectorAll(".theme-opt").forEach(function(o){ o.classList.toggle("active", o===opt); });
      menu.classList.remove("open");
    });
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", buildSwitcher);
  else buildSwitcher();
})();
